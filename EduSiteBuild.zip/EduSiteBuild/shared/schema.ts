import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const programmingLanguages = pgTable("programming_languages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  useCases: text("use_cases").array().notNull(),
  features: text("features").array().notNull(),
  workingMethod: text("working_method").notNull(),
  realLifeExamples: text("real_life_examples").array().notNull(),
  codeSnippet: text("code_snippet").notNull(),
  bestPractices: text("best_practices").array().notNull(),
  learningTips: text("learning_tips").array().notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  questionText: text("question_text").notNull(),
  choices: text("choices").array().notNull(),
  correctAnswer: integer("correct_answer").notNull(),
  explanation: text("explanation").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull(),
  description: text("description").notNull(),
  technologies: text("technologies").array().notNull(),
  category: text("category").notNull(),
  imagePath: text("image_path"),
  demoUrl: text("demo_url"),
  features: text("features").array().notNull(),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("coming_soon"),
  videoUrls: text("video_urls").array(),
  thumbnailPath: text("thumbnail_path"),
  duration: text("duration"),
  level: text("level").notNull(),
});

export const learningPaths = pgTable("learning_paths", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull(),
  description: text("description").notNull(),
  steps: jsonb("steps").notNull().$type<{ order: number; title: string; description: string; icon: string }[]>(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  estimatedTime: text("estimated_time").notNull(),
});

export const hardwareComponents = pgTable("hardware_components", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar").notNull(),
  description: text("description").notNull(),
  function: text("function").notNull(),
  specifications: text("specifications").array().notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(),
});

export const specializations = pgTable("specializations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull(),
  description: text("description").notNull(),
  skills: text("skills").array().notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
});

export const additionalSections = pgTable("additional_sections", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull(),
  description: text("description").notNull(),
  content: jsonb("content").notNull(),
  icon: text("icon").notNull(),
  type: text("type").notNull(),
});

export const insertProgrammingLanguageSchema = createInsertSchema(programmingLanguages).omit({ id: true });
export const insertQuestionSchema = createInsertSchema(questions).omit({ id: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true });
export const insertCourseSchema = createInsertSchema(courses).omit({ id: true });
export const insertLearningPathSchema = createInsertSchema(learningPaths).omit({ id: true });
export const insertHardwareComponentSchema = createInsertSchema(hardwareComponents).omit({ id: true });
export const insertSpecializationSchema = createInsertSchema(specializations).omit({ id: true });
export const insertAdditionalSectionSchema = createInsertSchema(additionalSections).omit({ id: true });

export type InsertProgrammingLanguage = z.infer<typeof insertProgrammingLanguageSchema>;
export type ProgrammingLanguage = typeof programmingLanguages.$inferSelect;

export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Question = typeof questions.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

export type InsertLearningPath = z.infer<typeof insertLearningPathSchema>;
export type LearningPath = typeof learningPaths.$inferSelect;

export type InsertHardwareComponent = z.infer<typeof insertHardwareComponentSchema>;
export type HardwareComponent = typeof hardwareComponents.$inferSelect;

export type InsertSpecialization = z.infer<typeof insertSpecializationSchema>;
export type Specialization = typeof specializations.$inferSelect;

export type InsertAdditionalSection = z.infer<typeof insertAdditionalSectionSchema>;
export type AdditionalSection = typeof additionalSections.$inferSelect;
