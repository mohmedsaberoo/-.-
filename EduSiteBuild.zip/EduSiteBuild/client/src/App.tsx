import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CyberBackground } from "@/components/CyberBackground";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import Home from "@/pages/Home";
import Languages from "@/pages/Languages";
import Hardware from "@/pages/Hardware";
import About from "@/pages/About";
import Questions from "@/pages/Questions";
import Projects from "@/pages/Projects";
import Specializations from "@/pages/Specializations";
import LearningPaths from "@/pages/LearningPaths";
import Courses from "@/pages/Courses";
import Resources from "@/pages/Resources";
import Tools from "@/pages/Tools";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/languages" component={Languages} />
      <Route path="/hardware" component={Hardware} />
      <Route path="/about" component={About} />
      <Route path="/questions" component={Questions} />
      <Route path="/projects" component={Projects} />
      <Route path="/specializations" component={Specializations} />
      <Route path="/learning-paths" component={LearningPaths} />
      <Route path="/courses" component={Courses} />
      <Route path="/resources" component={Resources} />
      <Route path="/tools" component={Tools} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen flex flex-col relative overflow-x-hidden scrollbar-cyber">
          <CyberBackground />
          <Header />
          <main className="flex-1 relative z-10 pt-4">
            <Router />
          </main>
          <Footer />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
