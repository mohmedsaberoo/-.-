import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  color: string;
}

interface CircuitNode {
  x: number;
  y: number;
  connections: number[];
  pulsePhase: number;
}

export function CyberBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;

    canvas.width = width;
    canvas.height = height;

    const particles: Particle[] = [];
    const circuitNodes: CircuitNode[] = [];
    const colors = ['#00d4ff', '#9d4edd', '#00ffff', '#c77dff'];

    for (let i = 0; i < 60; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    const gridSize = 150;
    for (let x = gridSize; x < width; x += gridSize) {
      for (let y = gridSize; y < height; y += gridSize) {
        if (Math.random() > 0.6) {
          circuitNodes.push({
            x: x + (Math.random() - 0.5) * 50,
            y: y + (Math.random() - 0.5) * 50,
            connections: [],
            pulsePhase: Math.random() * Math.PI * 2,
          });
        }
      }
    }

    circuitNodes.forEach((node, i) => {
      circuitNodes.forEach((other, j) => {
        if (i !== j) {
          const dist = Math.hypot(node.x - other.x, node.y - other.y);
          if (dist < 200 && Math.random() > 0.5) {
            node.connections.push(j);
          }
        }
      });
    });

    let scanLineY = 0;
    let time = 0;

    const drawGrid = () => {
      ctx.strokeStyle = 'rgba(0, 212, 255, 0.03)';
      ctx.lineWidth = 1;

      for (let x = 0; x < width; x += 50) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      for (let y = 0; y < height; y += 50) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    };

    const drawParticles = () => {
      particles.forEach((p) => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(')', `, ${p.opacity})`).replace('rgb', 'rgba').replace('#', '');
        
        const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 3);
        gradient.addColorStop(0, p.color + 'aa');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.fill();

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;
      });
    };

    const drawCircuits = () => {
      circuitNodes.forEach((node, i) => {
        const pulse = Math.sin(time * 0.002 + node.pulsePhase) * 0.5 + 0.5;
        
        node.connections.forEach((j) => {
          const other = circuitNodes[j];
          const gradient = ctx.createLinearGradient(node.x, node.y, other.x, other.y);
          gradient.addColorStop(0, `rgba(0, 212, 255, ${0.1 * pulse})`);
          gradient.addColorStop(0.5, `rgba(157, 78, 221, ${0.2 * pulse})`);
          gradient.addColorStop(1, `rgba(0, 255, 255, ${0.1 * pulse})`);
          
          ctx.beginPath();
          ctx.moveTo(node.x, node.y);
          ctx.lineTo(other.x, other.y);
          ctx.strokeStyle = gradient;
          ctx.lineWidth = 1;
          ctx.stroke();
        });

        ctx.beginPath();
        ctx.arc(node.x, node.y, 3 + pulse * 2, 0, Math.PI * 2);
        const nodeGradient = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, 5 + pulse * 3);
        nodeGradient.addColorStop(0, `rgba(0, 212, 255, ${0.8 * pulse})`);
        nodeGradient.addColorStop(1, 'transparent');
        ctx.fillStyle = nodeGradient;
        ctx.fill();
      });
    };

    const drawScanLine = () => {
      const gradient = ctx.createLinearGradient(0, scanLineY - 50, 0, scanLineY + 50);
      gradient.addColorStop(0, 'transparent');
      gradient.addColorStop(0.5, 'rgba(0, 212, 255, 0.1)');
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, scanLineY - 50, width, 100);
      
      scanLineY += 1;
      if (scanLineY > height + 50) scanLineY = -50;
    };

    const drawDigitalRain = () => {
      const chars = '01';
      ctx.font = '12px Fira Code';
      
      for (let i = 0; i < 10; i++) {
        const x = Math.random() * width;
        const y = (time * 0.5 + i * 100) % height;
        const char = chars[Math.floor(Math.random() * chars.length)];
        const opacity = Math.random() * 0.1;
        
        ctx.fillStyle = `rgba(0, 212, 255, ${opacity})`;
        ctx.fillText(char, x, y);
      }
    };

    const animate = () => {
      ctx.fillStyle = 'rgba(10, 10, 15, 0.1)';
      ctx.fillRect(0, 0, width, height);

      drawGrid();
      drawCircuits();
      drawParticles();
      drawScanLine();
      drawDigitalRain();

      time++;
      animationRef.current = requestAnimationFrame(animate);
    };

    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };

    window.addEventListener('resize', handleResize);
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0 pointer-events-none"
      style={{ background: 'linear-gradient(180deg, #0a0a0f 0%, #121218 50%, #0a0a0f 100%)' }}
    />
  );
}
