import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, X, Cpu, Home, Code, HardDrive, User, HelpCircle, FolderKanban, Star, Map, GraduationCap, Layers, Sparkles } from 'lucide-react';

const navItems = [
  { href: '/', label: 'الرئيسية', icon: Home },
  { href: '/languages', label: 'لغات البرمجة', icon: Code },
  { href: '/hardware', label: 'الهاردوير', icon: HardDrive },
  { href: '/about', label: 'من أنا', icon: User },
  { href: '/questions', label: 'الأسئلة', icon: HelpCircle },
  { href: '/projects', label: 'مشاريعي', icon: FolderKanban },
  { href: '/specializations', label: 'تخصصاتي', icon: Star },
  { href: '/learning-paths', label: 'المسارات', icon: Map },
  { href: '/courses', label: 'الكورسات', icon: GraduationCap },
  { href: '/resources', label: 'الموارد', icon: Layers },
  { href: '/tools', label: 'الأدوات', icon: Sparkles },
];

export function Header() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-primary/20" data-testid="header">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-secondary/5" />
        <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent scan-line" />
        
        <nav className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <Link href="/" className="flex items-center gap-3 group" data-testid="link-logo">
              <div className="relative">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <Cpu className="w-6 h-6 text-primary-foreground" />
                </div>
                <div className="absolute inset-0 rounded-lg bg-primary/30 blur-lg opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="flex flex-col">
                <span className="font-display text-xl font-bold text-gradient" data-testid="text-logo-title">Eleven</span>
                <span className="text-xs text-muted-foreground">منصة تعليمية</span>
              </div>
            </Link>

            <div className="hidden lg:flex items-center gap-1">
              {navItems.slice(0, 7).map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={isActive ? 'default' : 'ghost'}
                      size="sm"
                      className={`gap-2 ${isActive ? 'neon-border' : ''}`}
                      data-testid={`link-nav-${item.href.replace('/', '') || 'home'}`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </Button>
                  </Link>
                );
              })}
            </div>

            <div className="hidden lg:flex items-center gap-2">
              {navItems.slice(7).map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={isActive ? 'default' : 'ghost'}
                      size="icon"
                      className={isActive ? 'neon-border' : ''}
                      data-testid={`link-nav-${item.href.replace('/', '')}`}
                    >
                      <Icon className="w-4 h-4" />
                    </Button>
                  </Link>
                );
              })}
            </div>

            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="glass-card border-primary/20 w-72">
                <div className="flex flex-col gap-2 mt-8">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location === item.href;
                    return (
                      <Link key={item.href} href={item.href} onClick={() => setIsOpen(false)}>
                        <Button
                          variant={isActive ? 'default' : 'ghost'}
                          className={`w-full justify-start gap-3 ${isActive ? 'neon-border' : ''}`}
                          data-testid={`link-mobile-nav-${item.href.replace('/', '') || 'home'}`}
                        >
                          <Icon className="w-5 h-5" />
                          <span>{item.label}</span>
                        </Button>
                      </Link>
                    );
                  })}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </nav>
      </div>
    </header>
  );
}
