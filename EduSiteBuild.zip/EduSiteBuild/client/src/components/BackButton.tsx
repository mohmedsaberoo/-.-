import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export function BackButton() {
  const [, setLocation] = useLocation();

  const handleBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      setLocation('/');
    }
  };

  return (
    <Button
      onClick={handleBack}
      variant="outline"
      className="fixed bottom-6 left-6 z-40 glass-card-hover neon-border gap-2 animate-float"
      data-testid="button-back"
    >
      <ArrowRight className="w-4 h-4" />
      <span>الرجوع إلى الوراء</span>
    </Button>
  );
}
