import { Link } from 'wouter';
import { Cpu, Facebook, MessageCircle, Heart, Code, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Footer() {
  return (
    <footer className="relative glass-card border-t border-primary/20 mt-auto" data-testid="footer">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col gap-4">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Cpu className="w-6 h-6 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="font-display text-xl font-bold text-gradient">Eleven</span>
                <span className="text-xs text-muted-foreground">منصة تعليمية</span>
              </div>
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed">
              منصة تعليمية متكاملة لتعلم البرمجة والتقنية. نقدم محتوى عربي احترافي يساعدك على بناء مستقبلك في عالم التكنولوجيا.
            </p>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="font-display text-lg font-semibold text-gradient">روابط سريعة</h3>
            <div className="grid grid-cols-2 gap-2">
              <Link href="/languages">
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="link-footer-languages">
                  <Code className="w-4 h-4" />
                  لغات البرمجة
                </Button>
              </Link>
              <Link href="/hardware">
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="link-footer-hardware">
                  <Cpu className="w-4 h-4" />
                  الهاردوير
                </Button>
              </Link>
              <Link href="/projects">
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="link-footer-projects">
                  <ExternalLink className="w-4 h-4" />
                  مشاريعي
                </Button>
              </Link>
              <Link href="/courses">
                <Button variant="ghost" size="sm" className="w-full justify-start gap-2" data-testid="link-footer-courses">
                  <ExternalLink className="w-4 h-4" />
                  الكورسات
                </Button>
              </Link>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="font-display text-lg font-semibold text-gradient">تواصل معي</h3>
            <div className="flex gap-3">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg glass-card-hover flex items-center justify-center group"
                data-testid="link-social-facebook"
              >
                <Facebook className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
              </a>
              <a 
                href="https://wa.me/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg glass-card-hover flex items-center justify-center group"
                data-testid="link-social-whatsapp"
              >
                <MessageCircle className="w-5 h-5 text-muted-foreground group-hover:text-green-500 transition-colors" />
              </a>
            </div>
            <p className="text-sm text-muted-foreground">
              أبو صابر (Eleven) - مطور ومعلم برمجة
            </p>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border/50 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground flex items-center gap-2">
            صنع بـ <Heart className="w-4 h-4 text-destructive" /> بواسطة Eleven
          </p>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} جميع الحقوق محفوظة
          </p>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-[2px] overflow-hidden">
        <div className="w-full h-full bg-gradient-to-r from-transparent via-primary to-transparent animate-scan-line" />
      </div>
    </footer>
  );
}
