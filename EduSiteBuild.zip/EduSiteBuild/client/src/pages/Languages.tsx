import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { BackButton } from '@/components/BackButton';
import { PageLoading, GridSkeleton } from '@/components/LoadingSpinner';
import { Code, Lightbulb, Wrench, BookOpen, Target, Zap } from 'lucide-react';
import type { ProgrammingLanguage } from '@shared/schema';

const iconMap: Record<string, string> = {
  python: '🐍',
  javascript: '💛',
  typescript: '💙',
  java: '☕',
  cpp: '⚡',
  csharp: '💜',
  go: '🔵',
  rust: '🦀',
  php: '🐘',
  ruby: '💎',
};

export default function Languages() {
  const { data: languages, isLoading, error } = useQuery<ProgrammingLanguage[]>({
    queryKey: ['/api/languages'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-languages-loading">
        <PageLoading />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24 text-center" data-testid="page-languages-error">
        <p className="text-destructive">حدث خطأ في تحميل البيانات</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20" data-testid="page-languages">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <Code className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">لغات البرمجة</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-languages-title">
              تعلم لغات البرمجة
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              اكتشف أشهر لغات البرمجة مع شرح مفصل لكل لغة واستخداماتها وأمثلة عملية
            </p>
          </div>

          <div className="space-y-8">
            {languages?.map((lang, index) => (
              <Card 
                key={lang.id} 
                className="glass-card-hover overflow-visible animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
                data-testid={`card-language-${lang.id}`}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start gap-4 flex-wrap">
                    <div 
                      className="w-16 h-16 rounded-xl flex items-center justify-center text-3xl hologram-effect"
                      style={{ backgroundColor: `${lang.color}20`, borderColor: lang.color }}
                    >
                      {iconMap[lang.name.toLowerCase()] || '💻'}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-2xl mb-2 flex items-center gap-3 flex-wrap">
                        <span className="text-gradient">{lang.nameAr}</span>
                        <Badge variant="outline" className="font-mono">{lang.name}</Badge>
                      </CardTitle>
                      <p className="text-muted-foreground">{lang.description}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="usecases" className="border-border/50">
                      <AccordionTrigger className="hover:no-underline gap-2">
                        <div className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-primary" />
                          <span>استخدامات اللغة</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="flex flex-wrap gap-2 pt-2">
                          {lang.useCases?.map((useCase, i) => (
                            <Badge key={i} variant="secondary" className="glass-card">
                              {useCase}
                            </Badge>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="features" className="border-border/50">
                      <AccordionTrigger className="hover:no-underline gap-2">
                        <div className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-primary" />
                          <span>مميزات اللغة</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="space-y-2 pt-2">
                          {lang.features?.map((feature, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <span className="text-primary mt-1">•</span>
                              <span className="text-muted-foreground">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="working" className="border-border/50">
                      <AccordionTrigger className="hover:no-underline gap-2">
                        <div className="flex items-center gap-2">
                          <Wrench className="w-4 h-4 text-primary" />
                          <span>طريقة العمل</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <p className="text-muted-foreground pt-2 leading-relaxed">
                          {lang.workingMethod}
                        </p>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="examples" className="border-border/50">
                      <AccordionTrigger className="hover:no-underline gap-2">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-primary" />
                          <span>أمثلة من الحياة الواقعية</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="flex flex-wrap gap-2 pt-2">
                          {lang.realLifeExamples?.map((example, i) => (
                            <Badge key={i} variant="outline" className="glass-card">
                              {example}
                            </Badge>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="code" className="border-border/50">
                      <AccordionTrigger className="hover:no-underline gap-2">
                        <div className="flex items-center gap-2">
                          <Code className="w-4 h-4 text-primary" />
                          <span>مثال على الكود</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <pre className="glass-card p-4 rounded-lg overflow-x-auto text-sm font-mono mt-2 neon-border" dir="ltr">
                          <code className="text-foreground">{lang.codeSnippet}</code>
                        </pre>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="tips" className="border-border/50">
                      <AccordionTrigger className="hover:no-underline gap-2">
                        <div className="flex items-center gap-2">
                          <Lightbulb className="w-4 h-4 text-primary" />
                          <span>نصائح للتعلم</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="space-y-2 pt-2">
                          {lang.learningTips?.map((tip, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <span className="text-primary">💡</span>
                              <span className="text-muted-foreground">{tip}</span>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            ))}
          </div>

          {(!languages || languages.length === 0) && !isLoading && (
            <div className="text-center py-12 glass-card rounded-xl">
              <Code className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد لغات برمجة متاحة حالياً</p>
            </div>
          )}
        </div>
      </section>

      <BackButton />
    </div>
  );
}
