import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { Sparkles, ExternalLink, Code, Terminal, Palette, Wrench, Zap, Box } from 'lucide-react';
import type { AdditionalSection } from '@shared/schema';

const categoryIcons: Record<string, typeof Code> = {
  development: Code,
  terminal: Terminal,
  design: Palette,
  utility: Wrench,
  productivity: Zap,
  other: Box,
};

export default function Tools() {
  const { data: sections, isLoading } = useQuery<AdditionalSection[]>({
    queryKey: ['/api/sections', 'tools'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-tools-loading">
        <PageLoading />
      </div>
    );
  }

  const toolsSection = sections?.find(s => s.type === 'tools');
  const tools = toolsSection?.content as { name: string; description: string; url: string; category: string; free: boolean }[] | undefined;

  return (
    <div className="min-h-screen pt-20" data-testid="page-tools">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-secondary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <Sparkles className="w-4 h-4 text-secondary" />
              <span className="text-sm text-muted-foreground">الأدوات</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient-purple mb-4" data-testid="text-tools-title">
              أدوات المطور
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              مجموعة من الأدوات المفيدة التي يستخدمها المطورون في عملهم اليومي
            </p>
          </div>

          {tools && tools.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tools.map((tool, index) => {
                const Icon = categoryIcons[tool.category] || Sparkles;
                return (
                  <Card 
                    key={index} 
                    className="glass-card-hover group overflow-visible animate-slide-up"
                    style={{ animationDelay: `${index * 0.1}s` }}
                    data-testid={`card-tool-${index}`}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-secondary to-accent flex items-center justify-center group-hover:scale-110 transition-transform hologram-effect">
                          <Icon className="w-6 h-6 text-primary-foreground" />
                        </div>
                        {tool.free && (
                          <Badge className="bg-green-500/20 text-green-500">
                            مجاني
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-lg group-hover:text-gradient-purple transition-all mt-4">
                        {tool.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground text-sm mb-4">
                        {tool.description}
                      </p>
                      <Badge variant="outline" className="mb-4">
                        {tool.category}
                      </Badge>
                      {tool.url && (
                        <a href={tool.url} target="_blank" rel="noopener noreferrer">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="w-full gap-2 group-hover:neon-border-purple transition-all"
                            data-testid={`button-tool-link-${index}`}
                          >
                            <ExternalLink className="w-4 h-4" />
                            <span>زيارة الأداة</span>
                          </Button>
                        </a>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 glass-card rounded-xl">
              <Sparkles className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-2">لا توجد أدوات متاحة حالياً</p>
              <p className="text-sm text-muted-foreground">
                سيتم إضافة أدوات مفيدة قريباً!
              </p>
            </div>
          )}

          <div className="mt-16 grid md:grid-cols-2 gap-6">
            <Card className="glass-card-hover overflow-visible" data-testid="card-essential-tools">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-5 h-5 text-primary" />
                  <span className="text-gradient">أدوات أساسية للمبتدئين</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    <span>محرر أكواد (VS Code)</span>
                  </li>
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    <span>نظام التحكم بالإصدارات (Git)</span>
                  </li>
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    <span>متصفح مع أدوات المطور</span>
                  </li>
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    <span>Terminal / Command Line</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="glass-card-hover overflow-visible" data-testid="card-advanced-tools">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-secondary" />
                  <span className="text-gradient-purple">أدوات متقدمة</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    <span>Docker للحاويات</span>
                  </li>
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    <span>Postman لاختبار APIs</span>
                  </li>
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    <span>Figma للتصميم</span>
                  </li>
                  <li className="flex items-center gap-3 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    <span>GitHub Actions للأتمتة</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <BackButton />
    </div>
  );
}
