import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { FolderKanban, ExternalLink, Code, Layers, Eye, CheckCircle } from 'lucide-react';
import type { Project } from '@shared/schema';

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [filter, setFilter] = useState<string>('all');

  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  const categories = projects 
    ? ['all', ...new Set(projects.map(p => p.category))]
    : ['all'];

  const filteredProjects = projects?.filter(p => 
    filter === 'all' ? true : p.category === filter
  );

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-projects-loading">
        <PageLoading />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20" data-testid="page-projects">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <FolderKanban className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">مشاريعي</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-projects-title">
              أعمالي ومشاريعي
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              استعرض مجموعة من المشاريع التي قمت بتطويرها باستخدام تقنيات مختلفة
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category}
                variant={filter === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter(category)}
                className={filter === category ? 'neon-border' : 'glass-card-hover'}
                data-testid={`button-filter-${category}`}
              >
                {category === 'all' ? 'الكل' : category}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects?.map((project, index) => (
              <Card 
                key={project.id} 
                className="glass-card-hover group cursor-pointer overflow-visible animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
                onClick={() => setSelectedProject(project)}
                data-testid={`card-project-${project.id}`}
              >
                <div className="relative h-48 rounded-t-lg overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 flex items-center justify-center">
                    <Code className="w-16 h-16 text-primary/40" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
                  <div className="absolute bottom-4 right-4">
                    <Badge variant="secondary" className="glass-card">
                      {project.category}
                    </Badge>
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl group-hover:text-gradient transition-all">
                    {project.titleAr}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {project.technologies?.slice(0, 4).map((tech, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                    {project.technologies && project.technologies.length > 4 && (
                      <Badge variant="outline" className="text-xs">
                        +{project.technologies.length - 4}
                      </Badge>
                    )}
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full gap-2 group-hover:neon-border transition-all"
                    data-testid={`button-view-project-${project.id}`}
                  >
                    <Eye className="w-4 h-4" />
                    <span>عرض المشروع</span>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {(!filteredProjects || filteredProjects.length === 0) && (
            <div className="text-center py-12 glass-card rounded-xl">
              <FolderKanban className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد مشاريع متاحة حالياً</p>
            </div>
          )}
        </div>
      </section>

      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        <DialogContent className="glass-card border-primary/20 max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-project-details">
          {selectedProject && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl text-gradient">
                  {selectedProject.titleAr}
                </DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  {selectedProject.title}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6 mt-4">
                <div className="h-48 rounded-lg overflow-hidden bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 flex items-center justify-center">
                  <Code className="w-20 h-20 text-primary/40" />
                </div>

                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-primary" />
                    الوصف
                  </h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {selectedProject.description}
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Code className="w-4 h-4 text-primary" />
                    التقنيات المستخدمة
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.technologies?.map((tech, i) => (
                      <Badge key={i} variant="secondary" className="glass-card">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>

                {selectedProject.features && selectedProject.features.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-primary" />
                      المميزات
                    </h4>
                    <ul className="space-y-2">
                      {selectedProject.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <span className="text-primary mt-1">•</span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedProject.demoUrl && (
                  <a 
                    href={selectedProject.demoUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    data-testid="link-project-demo"
                  >
                    <Button className="w-full gap-2 neon-border">
                      <ExternalLink className="w-4 h-4" />
                      <span>عرض المشروع</span>
                    </Button>
                  </a>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <BackButton />
    </div>
  );
}
