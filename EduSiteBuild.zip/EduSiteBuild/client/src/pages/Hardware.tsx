import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { HardDrive, Cpu, MemoryStick, Monitor, Zap, Fan, Box, Layers } from 'lucide-react';
import type { HardwareComponent } from '@shared/schema';

const categoryIcons: Record<string, typeof Cpu> = {
  processor: Cpu,
  memory: MemoryStick,
  storage: HardDrive,
  display: Monitor,
  power: Zap,
  cooling: Fan,
  peripheral: Box,
  motherboard: Layers,
};

const categoryNames: Record<string, string> = {
  processor: 'المعالج',
  memory: 'الذاكرة',
  storage: 'التخزين',
  display: 'العرض',
  power: 'الطاقة',
  cooling: 'التبريد',
  peripheral: 'الملحقات',
  motherboard: 'اللوحة الأم',
};

export default function Hardware() {
  const { data: components, isLoading } = useQuery<HardwareComponent[]>({
    queryKey: ['/api/hardware'],
  });

  const categories = components 
    ? [...new Set(components.map(c => c.category))]
    : [];

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-hardware-loading">
        <PageLoading />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20" data-testid="page-hardware">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-secondary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <HardDrive className="w-4 h-4 text-secondary" />
              <span className="text-sm text-muted-foreground">قسم الهاردوير</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient-purple mb-4" data-testid="text-hardware-title">
              مكونات الكمبيوتر
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              تعرف على مكونات الكمبيوتر المختلفة والفرق بين الهاردوير والسوفتوير
            </p>
          </div>

          <div className="glass-card rounded-xl p-6 md:p-8 mb-12 gradient-border">
            <h2 className="text-2xl font-bold text-gradient mb-6">ما هو الهاردوير؟</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <HardDrive className="w-5 h-5 text-primary" />
                  الهاردوير (Hardware)
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  الهاردوير هو كل الأجزاء المادية والملموسة في الكمبيوتر التي يمكنك رؤيتها ولمسها. 
                  يشمل ذلك المعالج (CPU)، الذاكرة العشوائية (RAM)، القرص الصلب، اللوحة الأم، 
                  كرت الشاشة، والشاشة نفسها.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    الأجزاء المادية الملموسة
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    يمكن استبدالها وصيانتها
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    تحتاج للكهرباء للعمل
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-secondary" />
                  السوفتوير (Software)
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  السوفتوير هو البرامج والتطبيقات التي تعمل على الهاردوير. 
                  يشمل ذلك نظام التشغيل (Windows, macOS, Linux)، البرامج المكتبية، 
                  المتصفحات، الألعاب، وجميع التطبيقات الأخرى.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    البرامج والتطبيقات
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    يمكن تحديثها وتطويرها
                  </li>
                  <li className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-secondary" />
                    تحتاج للهاردوير للعمل
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {categories.length > 0 ? (
            <Tabs defaultValue={categories[0]} className="w-full">
              <TabsList className="w-full flex-wrap h-auto gap-2 bg-transparent justify-start mb-8">
                {categories.map((category) => {
                  const Icon = categoryIcons[category] || Box;
                  return (
                    <TabsTrigger 
                      key={category} 
                      value={category}
                      className="glass-card data-[state=active]:neon-border-purple gap-2"
                      data-testid={`tab-category-${category}`}
                    >
                      <Icon className="w-4 h-4" />
                      {categoryNames[category] || category}
                    </TabsTrigger>
                  );
                })}
              </TabsList>

              {categories.map((category) => (
                <TabsContent key={category} value={category}>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {components
                      ?.filter(c => c.category === category)
                      .map((component, index) => {
                        const Icon = categoryIcons[component.category] || Box;
                        return (
                          <Card 
                            key={component.id} 
                            className="glass-card-hover animate-slide-up overflow-visible"
                            style={{ animationDelay: `${index * 0.1}s` }}
                            data-testid={`card-component-${component.id}`}
                          >
                            <CardHeader className="pb-2">
                              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-secondary to-accent flex items-center justify-center mb-4 hologram-effect">
                                <Icon className="w-6 h-6 text-primary-foreground" />
                              </div>
                              <CardTitle className="text-xl">
                                <span className="text-gradient-purple">{component.nameAr}</span>
                                <Badge variant="outline" className="mr-2 font-mono text-xs">
                                  {component.name}
                                </Badge>
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <p className="text-muted-foreground text-sm mb-4">
                                {component.description}
                              </p>
                              <div className="space-y-2">
                                <p className="text-sm font-semibold text-foreground">الوظيفة:</p>
                                <p className="text-sm text-muted-foreground">
                                  {component.function}
                                </p>
                              </div>
                              {component.specifications?.length > 0 && (
                                <div className="mt-4">
                                  <p className="text-sm font-semibold text-foreground mb-2">المواصفات:</p>
                                  <div className="flex flex-wrap gap-1">
                                    {component.specifications.map((spec, i) => (
                                      <Badge key={i} variant="secondary" className="text-xs">
                                        {spec}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        );
                      })}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          ) : (
            <div className="text-center py-12 glass-card rounded-xl">
              <HardDrive className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد مكونات متاحة حالياً</p>
            </div>
          )}
        </div>
      </section>

      <BackButton />
    </div>
  );
}
