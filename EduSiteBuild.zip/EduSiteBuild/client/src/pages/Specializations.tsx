import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { Star, Code, Layout, Database, Server, Smartphone, Palette, Brain, Shield } from 'lucide-react';
import type { Specialization } from '@shared/schema';

const iconMap: Record<string, typeof Code> = {
  frontend: Layout,
  backend: Server,
  database: Database,
  mobile: Smartphone,
  design: Palette,
  ai: Brain,
  security: Shield,
  fullstack: Code,
};

export default function Specializations() {
  const { data: specializations, isLoading } = useQuery<Specialization[]>({
    queryKey: ['/api/specializations'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-specializations-loading">
        <PageLoading />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20" data-testid="page-specializations">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-secondary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <Star className="w-4 h-4 text-secondary" />
              <span className="text-sm text-muted-foreground">تخصصاتي</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient-purple mb-4" data-testid="text-specializations-title">
              مجالات التخصص
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              اكتشف المجالات التي أتخصص فيها والمهارات التي أملكها
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {specializations?.map((spec, index) => {
              const Icon = iconMap[spec.icon] || Star;
              return (
                <Card 
                  key={spec.id} 
                  className="glass-card-hover group overflow-visible animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                  data-testid={`card-specialization-${spec.id}`}
                >
                  <CardHeader className="pb-2">
                    <div 
                      className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 hologram-effect"
                      style={{ 
                        backgroundColor: `${spec.color}20`,
                        boxShadow: `0 0 20px ${spec.color}40`
                      }}
                    >
                      <Icon className="w-7 h-7" style={{ color: spec.color }} />
                    </div>
                    <CardTitle className="text-xl group-hover:text-gradient-purple transition-all">
                      {spec.titleAr}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                      {spec.description}
                    </p>
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-foreground">المهارات:</p>
                      <div className="flex flex-wrap gap-2">
                        {spec.skills?.map((skill, i) => (
                          <Badge 
                            key={i} 
                            variant="secondary" 
                            className="glass-card text-xs"
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {(!specializations || specializations.length === 0) && (
            <div className="text-center py-12 glass-card rounded-xl">
              <Star className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد تخصصات متاحة حالياً</p>
            </div>
          )}
        </div>
      </section>

      <BackButton />
    </div>
  );
}
