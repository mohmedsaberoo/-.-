import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Code, HardDrive, GraduationCap, Map, Star, Sparkles, Cpu, Zap, Brain, Rocket } from 'lucide-react';
import { BackButton } from '@/components/BackButton';

const features = [
  {
    icon: Code,
    title: 'لغات البرمجة',
    description: 'تعلم أشهر لغات البرمجة مع شرح مفصل وأمثلة عملية',
    href: '/languages',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: HardDrive,
    title: 'الهاردوير',
    description: 'فهم مكونات الكمبيوتر والفرق بين الهاردوير والسوفتوير',
    href: '/hardware',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: GraduationCap,
    title: 'الكورسات',
    description: 'كورسات تعليمية متكاملة لمختلف المستويات',
    href: '/courses',
    color: 'from-green-500 to-emerald-500',
  },
  {
    icon: Map,
    title: 'المسارات التعليمية',
    description: 'خطط تعليمية منظمة لتحقيق أهدافك البرمجية',
    href: '/learning-paths',
    color: 'from-orange-500 to-yellow-500',
  },
];

const stats = [
  { icon: Code, value: '10+', label: 'لغة برمجة' },
  { icon: Star, value: '25+', label: 'سؤال تفاعلي' },
  { icon: Rocket, value: '5+', label: 'مشاريع' },
  { icon: Brain, value: '∞', label: 'معرفة جديدة' },
];

export default function Home() {
  return (
    <div className="min-h-screen" data-testid="page-home">
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-background" />
        
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8 animate-slide-up">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">منصة Eleven التعليمية</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold mb-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <span className="text-gradient neon-text">ابدأ رحلتك</span>
              <br />
              <span className="text-foreground">في عالم البرمجة</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.2s' }}>
              منصة تعليمية عربية متكاملة تقدم لك محتوى احترافي في البرمجة والتقنية.
              تعلم بطريقة تفاعلية وممتعة مع أبو صابر (Eleven).
            </p>

            <div className="flex flex-wrap justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
              <Link href="/languages">
                <Button size="lg" className="gap-2 neon-border animate-glow-pulse" data-testid="button-start-learning">
                  <span>ابدأ التعلم الآن</span>
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <Link href="/about">
                <Button size="lg" variant="outline" className="gap-2 glass-card-hover" data-testid="button-about-me">
                  <span>تعرف علي</span>
                </Button>
              </Link>
            </div>

            <div className="mt-16 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20 blur-3xl" />
              <div className="relative glass-card p-8 rounded-2xl gradient-border">
                <div className="flex items-center justify-center gap-8 flex-wrap">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
                      <Cpu className="w-8 h-8 text-primary-foreground" />
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-gradient">AI</p>
                      <p className="text-sm text-muted-foreground">تقنيات حديثة</p>
                    </div>
                  </div>
                  <div className="h-12 w-px bg-border hidden md:block" />
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-secondary to-accent flex items-center justify-center animate-float" style={{ animationDelay: '0.5s' }}>
                      <Zap className="w-8 h-8 text-primary-foreground" />
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-gradient-purple">تفاعلي</p>
                      <p className="text-sm text-muted-foreground">تعلم بالممارسة</p>
                    </div>
                  </div>
                  <div className="h-12 w-px bg-border hidden md:block" />
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary flex items-center justify-center animate-float" style={{ animationDelay: '1s' }}>
                      <Brain className="w-8 h-8 text-primary-foreground" />
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-gradient">عربي</p>
                      <p className="text-sm text-muted-foreground">محتوى أصيل</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
      </section>

      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-gradient mb-4" data-testid="text-features-title">
              ماذا ستتعلم معنا؟
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              اكتشف مجموعة متنوعة من المواضيع التقنية والبرمجية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Link key={feature.href} href={feature.href}>
                  <Card 
                    className="glass-card-hover h-full group cursor-pointer overflow-visible"
                    style={{ animationDelay: `${index * 0.1}s` }}
                    data-testid={`card-feature-${feature.href.replace('/', '')}`}
                  >
                    <CardContent className="p-6 flex flex-col h-full">
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform hologram-effect`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-gradient transition-all">
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground text-sm flex-grow">
                        {feature.description}
                      </p>
                      <div className="mt-4 flex items-center gap-2 text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-sm">اكتشف المزيد</span>
                        <ArrowLeft className="w-4 h-4" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="glass-card rounded-2xl p-8 md:p-12 gradient-border">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div 
                    key={stat.label} 
                    className="text-center"
                    data-testid={`stat-${index}`}
                  >
                    <div className="w-12 h-12 mx-auto rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <p className="text-3xl md:text-4xl font-display font-bold text-gradient mb-2">
                      {stat.value}
                    </p>
                    <p className="text-muted-foreground text-sm">
                      {stat.label}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="glass-card rounded-2xl p-8 md:p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
                <span className="text-gradient">مستعد لتبدأ؟</span>
              </h2>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                انضم إلينا الآن واكتشف عالم البرمجة والتقنية بطريقة سهلة وممتعة
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link href="/questions">
                  <Button size="lg" className="gap-2" data-testid="button-start-quiz">
                    <span>اختبر معلوماتك</span>
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                </Link>
                <Link href="/projects">
                  <Button size="lg" variant="outline" className="gap-2" data-testid="button-view-projects">
                    <span>استعرض المشاريع</span>
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <BackButton />
    </div>
  );
}
