import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { HelpCircle, CheckCircle2, XCircle, ArrowLeft, RotateCcw, Trophy, Target, Brain } from 'lucide-react';
import type { Question } from '@shared/schema';

export default function Questions() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [showExplanation, setShowExplanation] = useState<number | null>(null);

  const { data: questions, isLoading } = useQuery<Question[]>({
    queryKey: ['/api/questions'],
  });

  const totalQuestions = questions?.length || 0;
  const answeredQuestions = Object.keys(selectedAnswers).length;
  const progress = totalQuestions > 0 ? (answeredQuestions / totalQuestions) * 100 : 0;

  const calculateScore = () => {
    if (!questions) return 0;
    let correct = 0;
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctAnswer) {
        correct++;
      }
    });
    return correct;
  };

  const handleSelectAnswer = (questionId: number, answerIndex: number) => {
    if (showResults) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: answerIndex }));
  };

  const handleSubmit = () => {
    setShowResults(true);
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setShowResults(false);
    setCurrentQuestion(0);
    setShowExplanation(null);
  };

  const handleNextQuestion = () => {
    if (questions && currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-questions-loading">
        <PageLoading />
      </div>
    );
  }

  const score = calculateScore();
  const scorePercentage = totalQuestions > 0 ? (score / totalQuestions) * 100 : 0;

  return (
    <div className="min-h-screen pt-20" data-testid="page-questions">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-accent/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <HelpCircle className="w-4 h-4 text-accent" />
              <span className="text-sm text-muted-foreground">قسم الأسئلة</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-questions-title">
              اختبر معلوماتك
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              اختبر معلوماتك في البرمجة والتقنية من خلال مجموعة من الأسئلة التفاعلية
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="glass-card rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between gap-4 flex-wrap mb-2">
                <span className="text-sm text-muted-foreground">التقدم</span>
                <span className="text-sm text-muted-foreground">
                  {answeredQuestions} / {totalQuestions}
                </span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            {showResults ? (
              <Card className="glass-card gradient-border overflow-visible animate-slide-up" data-testid="card-results">
                <CardHeader className="text-center pb-4">
                  <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-4">
                    <Trophy className="w-10 h-10 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-3xl text-gradient">النتيجة النهائية</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-6xl font-display font-bold mb-4">
                    <span className={scorePercentage >= 70 ? 'text-green-500' : scorePercentage >= 50 ? 'text-yellow-500' : 'text-red-500'}>
                      {score}
                    </span>
                    <span className="text-muted-foreground text-2xl"> / {totalQuestions}</span>
                  </div>
                  <p className="text-muted-foreground mb-6">
                    {scorePercentage >= 70 
                      ? 'ممتاز! أداء رائع' 
                      : scorePercentage >= 50 
                        ? 'جيد! استمر في التعلم' 
                        : 'لا بأس! حاول مرة أخرى'}
                  </p>
                  <Progress 
                    value={scorePercentage} 
                    className={`h-4 mb-8 ${scorePercentage >= 70 ? '[&>div]:bg-green-500' : scorePercentage >= 50 ? '[&>div]:bg-yellow-500' : '[&>div]:bg-red-500'}`} 
                  />

                  <div className="space-y-4 text-right max-h-96 overflow-y-auto pr-2 scrollbar-cyber">
                    {questions?.map((q, index) => {
                      const isCorrect = selectedAnswers[q.id] === q.correctAnswer;
                      return (
                        <div 
                          key={q.id} 
                          className={`glass-card p-4 rounded-lg ${isCorrect ? 'border-green-500/50' : 'border-red-500/50'} border`}
                          data-testid={`result-question-${q.id}`}
                        >
                          <div className="flex items-start gap-3">
                            {isCorrect ? (
                              <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                            ) : (
                              <XCircle className="w-5 h-5 text-red-500 mt-1 flex-shrink-0" />
                            )}
                            <div className="flex-1">
                              <p className="font-medium mb-2">
                                {index + 1}. {q.questionText}
                              </p>
                              <div className="text-sm space-y-1">
                                <p className="text-green-500">
                                  الإجابة الصحيحة: {q.choices?.[q.correctAnswer]}
                                </p>
                                {!isCorrect && (
                                  <p className="text-red-500">
                                    إجابتك: {q.choices?.[selectedAnswers[q.id]] || 'لم تجب'}
                                  </p>
                                )}
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="mt-2"
                                onClick={() => setShowExplanation(showExplanation === q.id ? null : q.id)}
                                data-testid={`button-explanation-${q.id}`}
                              >
                                <Brain className="w-4 h-4 ml-2" />
                                {showExplanation === q.id ? 'إخفاء الشرح' : 'عرض الشرح'}
                              </Button>
                              {showExplanation === q.id && (
                                <p className="text-muted-foreground text-sm mt-2 p-3 glass-card rounded-lg">
                                  {q.explanation}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <Button onClick={handleReset} className="mt-6 gap-2" data-testid="button-reset-quiz">
                    <RotateCcw className="w-4 h-4" />
                    <span>إعادة الاختبار</span>
                  </Button>
                </CardContent>
              </Card>
            ) : questions && questions.length > 0 ? (
              <div>
                <Card 
                  className="glass-card-hover overflow-visible animate-fade-in" 
                  key={currentQuestion}
                  data-testid={`card-question-${currentQuestion}`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between gap-2 flex-wrap mb-4">
                      <Badge variant="outline" className="gap-1">
                        <Target className="w-3 h-3" />
                        {questions[currentQuestion]?.category}
                      </Badge>
                      <Badge 
                        variant="secondary"
                        className={
                          questions[currentQuestion]?.difficulty === 'easy' 
                            ? 'bg-green-500/20 text-green-500' 
                            : questions[currentQuestion]?.difficulty === 'medium'
                              ? 'bg-yellow-500/20 text-yellow-500'
                              : 'bg-red-500/20 text-red-500'
                        }
                      >
                        {questions[currentQuestion]?.difficulty === 'easy' 
                          ? 'سهل' 
                          : questions[currentQuestion]?.difficulty === 'medium'
                            ? 'متوسط'
                            : 'صعب'}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl leading-relaxed">
                      <span className="text-primary">{currentQuestion + 1}.</span>{' '}
                      {questions[currentQuestion]?.questionText}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {questions[currentQuestion]?.choices?.map((choice, index) => {
                        const isSelected = selectedAnswers[questions[currentQuestion].id] === index;
                        return (
                          <button
                            key={index}
                            onClick={() => handleSelectAnswer(questions[currentQuestion].id, index)}
                            className={`w-full text-right p-4 rounded-lg border transition-all ${
                              isSelected
                                ? 'neon-border bg-primary/10'
                                : 'glass-card-hover'
                            }`}
                            data-testid={`button-choice-${index}`}
                          >
                            <div className="flex items-center gap-3">
                              <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                                isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted'
                              }`}>
                                {String.fromCharCode(65 + index)}
                              </span>
                              <span className={isSelected ? 'text-foreground' : 'text-muted-foreground'}>
                                {choice}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                <div className="flex items-center justify-between mt-6 gap-4">
                  <Button
                    variant="outline"
                    onClick={handlePrevQuestion}
                    disabled={currentQuestion === 0}
                    className="gap-2"
                    data-testid="button-prev-question"
                  >
                    <ArrowLeft className="w-4 h-4 rotate-180" />
                    <span>السابق</span>
                  </Button>

                  <div className="flex gap-2">
                    {questions.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentQuestion(index)}
                        className={`w-8 h-8 rounded-full text-sm font-medium transition-all ${
                          currentQuestion === index
                            ? 'bg-primary text-primary-foreground'
                            : selectedAnswers[questions[index]?.id] !== undefined
                              ? 'bg-green-500/20 text-green-500'
                              : 'bg-muted text-muted-foreground'
                        }`}
                        data-testid={`button-question-nav-${index}`}
                      >
                        {index + 1}
                      </button>
                    ))}
                  </div>

                  {currentQuestion === questions.length - 1 ? (
                    <Button
                      onClick={handleSubmit}
                      disabled={answeredQuestions < totalQuestions}
                      className="gap-2 neon-border"
                      data-testid="button-submit-quiz"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>إرسال</span>
                    </Button>
                  ) : (
                    <Button
                      onClick={handleNextQuestion}
                      className="gap-2"
                      data-testid="button-next-question"
                    >
                      <span>التالي</span>
                      <ArrowLeft className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 glass-card rounded-xl">
                <HelpCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">لا توجد أسئلة متاحة حالياً</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <BackButton />
    </div>
  );
}
