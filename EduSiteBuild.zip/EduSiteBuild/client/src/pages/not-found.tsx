import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 pt-20" data-testid="page-not-found">
      <div className="text-center">
        <div className="relative mb-8">
          <div className="text-[150px] md:text-[200px] font-display font-bold text-gradient opacity-20 select-none">
            404
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
              <AlertTriangle className="w-12 h-12 text-primary-foreground" />
            </div>
          </div>
        </div>
        
        <h1 className="text-3xl md:text-4xl font-display font-bold text-gradient mb-4">
          الصفحة غير موجودة
        </h1>
        <p className="text-muted-foreground mb-8 max-w-md mx-auto">
          عذراً، لم نتمكن من العثور على الصفحة التي تبحث عنها. قد تكون الصفحة قد حذفت أو أن الرابط غير صحيح.
        </p>
        
        <Link href="/">
          <Button size="lg" className="gap-2 neon-border" data-testid="button-go-home">
            <Home className="w-5 h-5" />
            <span>العودة للرئيسية</span>
          </Button>
        </Link>
      </div>
    </div>
  );
}
