import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { Map, Clock, CheckCircle, ArrowLeft, Rocket, Target, Code, Brain } from 'lucide-react';
import type { LearningPath } from '@shared/schema';

const iconMap: Record<string, typeof Code> = {
  code: Code,
  brain: Brain,
  rocket: Rocket,
  target: Target,
};

export default function LearningPaths() {
  const { data: paths, isLoading } = useQuery<LearningPath[]>({
    queryKey: ['/api/learning-paths'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-learning-paths-loading">
        <PageLoading />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20" data-testid="page-learning-paths">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-accent/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <Map className="w-4 h-4 text-accent" />
              <span className="text-sm text-muted-foreground">المسارات التعليمية</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-learning-paths-title">
              خطط تعلمك
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              اختر المسار التعليمي المناسب لك واتبع الخطوات المنظمة لتحقيق أهدافك
            </p>
          </div>

          <div className="space-y-8">
            {paths?.map((path, pathIndex) => {
              const PathIcon = iconMap[path.icon] || Map;
              const steps = path.steps as { order: number; title: string; description: string; icon: string }[];
              
              return (
                <Card 
                  key={path.id} 
                  className="glass-card-hover overflow-visible animate-slide-up"
                  style={{ animationDelay: `${pathIndex * 0.1}s` }}
                  data-testid={`card-path-${path.id}`}
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4 flex-wrap">
                      <div 
                        className="w-16 h-16 rounded-xl flex items-center justify-center hologram-effect"
                        style={{ 
                          backgroundColor: `${path.color}20`,
                          boxShadow: `0 0 20px ${path.color}40`
                        }}
                      >
                        <PathIcon className="w-8 h-8" style={{ color: path.color }} />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-2xl mb-2 text-gradient">
                          {path.titleAr}
                        </CardTitle>
                        <p className="text-muted-foreground mb-2">{path.description}</p>
                        <div className="flex items-center gap-4 flex-wrap">
                          <Badge variant="outline" className="gap-1">
                            <Clock className="w-3 h-3" />
                            {path.estimatedTime}
                          </Badge>
                          <Badge variant="secondary" className="gap-1">
                            <CheckCircle className="w-3 h-3" />
                            {steps?.length || 0} خطوات
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="relative">
                      <div className="absolute right-[27px] top-0 bottom-0 w-[2px] bg-gradient-to-b from-primary via-secondary to-accent" />
                      
                      <div className="space-y-6">
                        {steps?.sort((a, b) => a.order - b.order).map((step, stepIndex) => {
                          const StepIcon = iconMap[step.icon] || CheckCircle;
                          return (
                            <div 
                              key={stepIndex} 
                              className="relative flex gap-4 animate-slide-in-right"
                              style={{ animationDelay: `${(pathIndex * 0.1) + (stepIndex * 0.05)}s` }}
                            >
                              <div className="relative z-10 w-14 h-14 rounded-full bg-background border-2 border-primary flex items-center justify-center glass-card">
                                <span className="text-lg font-bold text-gradient">{step.order}</span>
                              </div>
                              <div className="flex-1 glass-card p-4 rounded-lg">
                                <h4 className="font-semibold mb-1 flex items-center gap-2">
                                  <StepIcon className="w-4 h-4 text-primary" />
                                  {step.title}
                                </h4>
                                <p className="text-muted-foreground text-sm">
                                  {step.description}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      <div className="relative flex gap-4 mt-6">
                        <div className="relative z-10 w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-pulse">
                          <Rocket className="w-6 h-6 text-primary-foreground" />
                        </div>
                        <div className="flex-1 glass-card p-4 rounded-lg gradient-border">
                          <h4 className="font-semibold text-gradient">النهاية</h4>
                          <p className="text-muted-foreground text-sm">
                            تهانينا! لقد أكملت المسار بنجاح
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {(!paths || paths.length === 0) && (
            <div className="text-center py-12 glass-card rounded-xl">
              <Map className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد مسارات تعليمية متاحة حالياً</p>
            </div>
          )}
        </div>
      </section>

      <BackButton />
    </div>
  );
}
