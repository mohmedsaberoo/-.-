import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BackButton } from '@/components/BackButton';
import { User, Code, Heart, Target, Facebook, MessageCircle, Mail, Calendar, Award, Sparkles } from 'lucide-react';

const skills = [
  'تطوير الويب',
  'React & TypeScript',
  'Node.js',
  'Python',
  'قواعد البيانات',
  'تصميم واجهات',
  'حل المشكلات',
  'التعليم والتدريب',
];

const achievements = [
  { icon: Code, label: 'مشاريع منجزة', value: '10+' },
  { icon: Award, label: 'سنوات الخبرة', value: '3+' },
  { icon: Heart, label: 'طلاب تعلموا', value: '100+' },
  { icon: Target, label: 'أهداف محققة', value: '∞' },
];

export default function About() {
  return (
    <div className="min-h-screen pt-20" data-testid="page-about">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-secondary/5 to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <User className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">من أنا</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-about-title">
              تعرف على Eleven
            </h1>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="glass-card rounded-2xl p-8 gradient-border mb-8">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="relative">
                  <div className="w-40 h-40 rounded-full bg-gradient-to-br from-primary via-secondary to-accent p-1">
                    <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
                      <div className="w-36 h-36 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                        <span className="text-6xl font-display font-bold text-gradient">11</span>
                      </div>
                    </div>
                  </div>
                  <div className="absolute -bottom-2 -right-2 w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-float">
                    <Sparkles className="w-6 h-6 text-primary-foreground" />
                  </div>
                </div>

                <div className="flex-1 text-center md:text-right">
                  <h2 className="text-3xl font-bold mb-2">
                    <span className="text-gradient">أبو صابر</span>
                    <Badge variant="outline" className="mr-3">Eleven</Badge>
                  </h2>
                  <p className="text-muted-foreground flex items-center justify-center md:justify-start gap-2 mb-4">
                    <Calendar className="w-4 h-4" />
                    15 سنة
                  </p>
                  <p className="text-foreground leading-relaxed">
                    مبرمج ومطور ويب شغوف بالتقنية والتعليم. أسعى لنشر المعرفة البرمجية باللغة العربية 
                    ومساعدة الآخرين في بدء رحلتهم في عالم البرمجة.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <Card className="glass-card-hover overflow-visible" data-testid="card-about-arabic">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <span className="text-sm">🇸🇦</span>
                    </div>
                    <h3 className="text-xl font-bold text-gradient">بالعربية</h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    أنا أبو صابر، المعروف باسم Eleven. عمري 15 سنة، وأنا شغوف جداً بعالم البرمجة والتقنية.
                    بدأت رحلتي في تعلم البرمجة منذ سن مبكرة، ومنذ ذلك الحين وأنا أسعى لتطوير مهاراتي باستمرار.
                  </p>
                  <p className="text-muted-foreground leading-relaxed text-sm mt-4">
                    رسالتي هي جعل البرمجة متاحة وسهلة للجميع باللغة العربية. 
                    أؤمن بأن كل شخص يمكنه تعلم البرمجة إذا وجد المحتوى المناسب والطريقة الصحيحة.
                    أعمل على إنشاء محتوى تعليمي عالي الجودة يساعد المبتدئين على فهم المفاهيم الأساسية
                    والانطلاق في عالم تطوير البرمجيات.
                  </p>
                  <p className="text-muted-foreground leading-relaxed text-sm mt-4">
                    خبرتي تشمل تطوير الويب الكامل، من الواجهات الأمامية باستخدام React و TypeScript
                    إلى الخوادم الخلفية باستخدام Node.js وقواعد البيانات المختلفة.
                    كما أهتم بتصميم تجارب المستخدم وإنشاء واجهات جذابة وسهلة الاستخدام.
                  </p>
                </CardContent>
              </Card>

              <Card className="glass-card-hover overflow-visible" data-testid="card-about-english">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-8 h-8 rounded-lg bg-secondary/10 flex items-center justify-center">
                      <span className="text-sm">🇬🇧</span>
                    </div>
                    <h3 className="text-xl font-bold text-gradient-purple">In English</h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed text-sm" dir="ltr">
                    I am Abu Saber, also known as Eleven. I'm 15 years old, and I'm deeply passionate 
                    about programming and technology. I started my programming journey at an early age, 
                    and since then, I've been continuously working to improve my skills.
                  </p>
                  <p className="text-muted-foreground leading-relaxed text-sm mt-4" dir="ltr">
                    My mission is to make programming accessible and easy for everyone in Arabic.
                    I believe that anyone can learn to code if they find the right content and approach.
                    I work on creating high-quality educational content that helps beginners understand
                    fundamental concepts and launch their journey in software development.
                  </p>
                  <p className="text-muted-foreground leading-relaxed text-sm mt-4" dir="ltr">
                    My expertise includes full-stack web development, from frontend interfaces using
                    React and TypeScript to backend servers using Node.js and various databases.
                    I'm also interested in UX design and creating attractive, user-friendly interfaces.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon;
                return (
                  <Card 
                    key={achievement.label} 
                    className="glass-card-hover overflow-visible text-center"
                    data-testid={`card-achievement-${index}`}
                  >
                    <CardContent className="p-4">
                      <Icon className="w-8 h-8 text-primary mx-auto mb-2" />
                      <p className="text-2xl font-bold text-gradient">{achievement.value}</p>
                      <p className="text-sm text-muted-foreground">{achievement.label}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <Card className="glass-card-hover mb-8 overflow-visible" data-testid="card-skills">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gradient mb-4">المهارات</h3>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <Badge 
                      key={skill} 
                      variant="secondary" 
                      className="glass-card px-4 py-2"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card gradient-border overflow-visible" data-testid="card-contact">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gradient mb-4">تواصل معي</h3>
                <div className="flex flex-wrap gap-4">
                  <a 
                    href="https://facebook.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    data-testid="link-about-facebook"
                  >
                    <Button variant="outline" className="gap-2 glass-card-hover">
                      <Facebook className="w-5 h-5 text-blue-500" />
                      <span>Facebook</span>
                    </Button>
                  </a>
                  <a 
                    href="https://wa.me/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    data-testid="link-about-whatsapp"
                  >
                    <Button variant="outline" className="gap-2 glass-card-hover">
                      <MessageCircle className="w-5 h-5 text-green-500" />
                      <span>WhatsApp</span>
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <BackButton />
    </div>
  );
}
