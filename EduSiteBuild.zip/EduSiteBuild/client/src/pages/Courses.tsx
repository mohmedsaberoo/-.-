import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { GraduationCap, Clock, Play, Lock, Sparkles, BookOpen, Video } from 'lucide-react';
import { useState } from 'react';
import type { Course } from '@shared/schema';

const levelColors: Record<string, string> = {
  beginner: 'text-green-500 bg-green-500/10',
  intermediate: 'text-yellow-500 bg-yellow-500/10',
  advanced: 'text-red-500 bg-red-500/10',
};

const levelNames: Record<string, string> = {
  beginner: 'مبتدئ',
  intermediate: 'متوسط',
  advanced: 'متقدم',
};

export default function Courses() {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const { data: courses, isLoading } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-courses-loading">
        <PageLoading />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20" data-testid="page-courses">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <GraduationCap className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">الكورسات</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-courses-title">
              الكورسات التعليمية
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              كورسات تعليمية متكاملة تغطي مختلف مجالات البرمجة والتقنية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses?.map((course, index) => (
              <Card 
                key={course.id} 
                className="glass-card-hover group overflow-visible animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
                data-testid={`card-course-${course.id}`}
              >
                <div className="relative h-40 rounded-t-lg overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-secondary/20 to-accent/30 flex items-center justify-center">
                    <GraduationCap className="w-16 h-16 text-primary/40" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
                  {course.status === 'coming_soon' && (
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-secondary text-secondary-foreground gap-1">
                        <Sparkles className="w-3 h-3" />
                        قريباً
                      </Badge>
                    </div>
                  )}
                  <div className="absolute bottom-4 right-4 flex items-center gap-2">
                    <Badge className={levelColors[course.level] || 'bg-muted'}>
                      {levelNames[course.level] || course.level}
                    </Badge>
                    {course.duration && (
                      <Badge variant="outline" className="glass-card gap-1">
                        <Clock className="w-3 h-3" />
                        {course.duration}
                      </Badge>
                    )}
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl group-hover:text-gradient transition-all">
                    {course.titleAr}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {course.description}
                  </p>
                  <Button 
                    variant={course.status === 'coming_soon' ? 'outline' : 'default'}
                    size="sm" 
                    className={`w-full gap-2 ${course.status === 'coming_soon' ? '' : 'neon-border'}`}
                    onClick={() => setSelectedCourse(course)}
                    data-testid={`button-enter-course-${course.id}`}
                  >
                    {course.status === 'coming_soon' ? (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>قريباً</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" />
                        <span>دخول الكورس</span>
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {(!courses || courses.length === 0) && (
            <div className="text-center py-12 glass-card rounded-xl">
              <GraduationCap className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد كورسات متاحة حالياً</p>
            </div>
          )}
        </div>
      </section>

      <Dialog open={!!selectedCourse} onOpenChange={() => setSelectedCourse(null)}>
        <DialogContent className="glass-card border-primary/20 max-w-lg" data-testid="dialog-course-details">
          {selectedCourse && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl text-gradient flex items-center gap-2">
                  <GraduationCap className="w-6 h-6" />
                  {selectedCourse.titleAr}
                </DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  {selectedCourse.title}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6 mt-4">
                {selectedCourse.status === 'coming_soon' ? (
                  <div className="text-center py-8">
                    <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-secondary to-accent flex items-center justify-center mb-4 animate-float">
                      <Sparkles className="w-10 h-10 text-primary-foreground" />
                    </div>
                    <h3 className="text-2xl font-bold text-gradient-purple mb-2">
                      سيتم التوفير قريباً
                    </h3>
                    <p className="text-muted-foreground">
                      نعمل حالياً على إعداد محتوى هذا الكورس. تابعنا للحصول على آخر التحديثات!
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-4 flex-wrap">
                      <Badge className={levelColors[selectedCourse.level] || 'bg-muted'}>
                        {levelNames[selectedCourse.level] || selectedCourse.level}
                      </Badge>
                      {selectedCourse.duration && (
                        <Badge variant="outline" className="gap-1">
                          <Clock className="w-3 h-3" />
                          {selectedCourse.duration}
                        </Badge>
                      )}
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2 flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-primary" />
                        الوصف
                      </h4>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {selectedCourse.description}
                      </p>
                    </div>

                    {selectedCourse.videoUrls && selectedCourse.videoUrls.length > 0 ? (
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <Video className="w-4 h-4 text-primary" />
                          الدروس
                        </h4>
                        <div className="space-y-2">
                          {selectedCourse.videoUrls.map((url, i) => (
                            <a
                              key={i}
                              href={url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 p-3 glass-card rounded-lg hover:neon-border transition-all"
                            >
                              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                                <Play className="w-5 h-5 text-primary" />
                              </div>
                              <span className="text-sm">الدرس {i + 1}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-4 glass-card rounded-lg">
                        <Video className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">
                          لا توجد دروس متاحة حالياً
                        </p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <BackButton />
    </div>
  );
}
