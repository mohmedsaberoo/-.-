import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/BackButton';
import { PageLoading } from '@/components/LoadingSpinner';
import { Layers, ExternalLink, BookOpen, Video, FileText, Link as LinkIcon } from 'lucide-react';
import type { AdditionalSection } from '@shared/schema';

const typeIcons: Record<string, typeof BookOpen> = {
  article: FileText,
  video: Video,
  course: BookOpen,
  link: LinkIcon,
};

export default function Resources() {
  const { data: sections, isLoading } = useQuery<AdditionalSection[]>({
    queryKey: ['/api/sections', 'resources'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24" data-testid="page-resources-loading">
        <PageLoading />
      </div>
    );
  }

  const resourceSection = sections?.find(s => s.type === 'resources');
  const resources = resourceSection?.content as { title: string; description: string; url: string; type: string }[] | undefined;

  return (
    <div className="min-h-screen pt-20" data-testid="page-resources">
      <section className="py-12 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
              <Layers className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">الموارد التعليمية</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient mb-4" data-testid="text-resources-title">
              موارد مفيدة
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              مجموعة من الموارد والمصادر التعليمية المفيدة لتطوير مهاراتك
            </p>
          </div>

          {resources && resources.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {resources.map((resource, index) => {
                const Icon = typeIcons[resource.type] || Layers;
                return (
                  <Card 
                    key={index} 
                    className="glass-card-hover group overflow-visible animate-slide-up"
                    style={{ animationDelay: `${index * 0.1}s` }}
                    data-testid={`card-resource-${index}`}
                  >
                    <CardHeader className="pb-2">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <Icon className="w-6 h-6 text-primary-foreground" />
                      </div>
                      <CardTitle className="text-lg group-hover:text-gradient transition-all">
                        {resource.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground text-sm mb-4">
                        {resource.description}
                      </p>
                      <Badge variant="outline" className="mb-4">
                        {resource.type}
                      </Badge>
                      {resource.url && (
                        <a href={resource.url} target="_blank" rel="noopener noreferrer">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="w-full gap-2 group-hover:neon-border transition-all"
                            data-testid={`button-resource-link-${index}`}
                          >
                            <ExternalLink className="w-4 h-4" />
                            <span>زيارة المصدر</span>
                          </Button>
                        </a>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 glass-card rounded-xl">
              <Layers className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-2">لا توجد موارد متاحة حالياً</p>
              <p className="text-sm text-muted-foreground">
                سيتم إضافة موارد تعليمية قريباً!
              </p>
            </div>
          )}

          <div className="mt-16 glass-card rounded-xl p-8 gradient-border">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gradient mb-4">
                هل لديك موارد مفيدة؟
              </h2>
              <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                شارك معنا الموارد التعليمية التي وجدتها مفيدة وساعد الآخرين في رحلة تعلمهم
              </p>
              <Button className="gap-2 neon-border" data-testid="button-suggest-resource">
                <Layers className="w-4 h-4" />
                <span>اقترح مورداً</span>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <BackButton />
    </div>
  );
}
