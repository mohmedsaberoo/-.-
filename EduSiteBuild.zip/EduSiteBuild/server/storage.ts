import { 
  programmingLanguages, 
  questions, 
  projects, 
  courses, 
  learningPaths, 
  hardwareComponents, 
  specializations,
  additionalSections,
  type ProgrammingLanguage, 
  type InsertProgrammingLanguage,
  type Question,
  type InsertQuestion,
  type Project,
  type InsertProject,
  type Course,
  type InsertCourse,
  type LearningPath,
  type InsertLearningPath,
  type HardwareComponent,
  type InsertHardwareComponent,
  type Specialization,
  type InsertSpecialization,
  type AdditionalSection,
  type InsertAdditionalSection,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getAllLanguages(): Promise<ProgrammingLanguage[]>;
  getLanguageById(id: number): Promise<ProgrammingLanguage | undefined>;
  createLanguage(language: InsertProgrammingLanguage): Promise<ProgrammingLanguage>;
  
  getAllQuestions(): Promise<Question[]>;
  getQuestionById(id: number): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  
  getAllProjects(): Promise<Project[]>;
  getProjectById(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  
  getAllCourses(): Promise<Course[]>;
  getCourseById(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  getAllLearningPaths(): Promise<LearningPath[]>;
  getLearningPathById(id: number): Promise<LearningPath | undefined>;
  createLearningPath(path: InsertLearningPath): Promise<LearningPath>;
  
  getAllHardwareComponents(): Promise<HardwareComponent[]>;
  getHardwareComponentById(id: number): Promise<HardwareComponent | undefined>;
  createHardwareComponent(component: InsertHardwareComponent): Promise<HardwareComponent>;
  
  getAllSpecializations(): Promise<Specialization[]>;
  getSpecializationById(id: number): Promise<Specialization | undefined>;
  createSpecialization(spec: InsertSpecialization): Promise<Specialization>;
  
  getAllSections(type?: string): Promise<AdditionalSection[]>;
  getSectionById(id: number): Promise<AdditionalSection | undefined>;
  createSection(section: InsertAdditionalSection): Promise<AdditionalSection>;
}

export class DatabaseStorage implements IStorage {
  async getAllLanguages(): Promise<ProgrammingLanguage[]> {
    return db.select().from(programmingLanguages);
  }

  async getLanguageById(id: number): Promise<ProgrammingLanguage | undefined> {
    const [language] = await db.select().from(programmingLanguages).where(eq(programmingLanguages.id, id));
    return language || undefined;
  }

  async createLanguage(language: InsertProgrammingLanguage): Promise<ProgrammingLanguage> {
    const [created] = await db.insert(programmingLanguages).values(language).returning();
    return created;
  }

  async getAllQuestions(): Promise<Question[]> {
    return db.select().from(questions);
  }

  async getQuestionById(id: number): Promise<Question | undefined> {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question || undefined;
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    const [created] = await db.insert(questions).values(question).returning();
    return created;
  }

  async getAllProjects(): Promise<Project[]> {
    return db.select().from(projects);
  }

  async getProjectById(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [created] = await db.insert(projects).values(project).returning();
    return created;
  }

  async getAllCourses(): Promise<Course[]> {
    return db.select().from(courses);
  }

  async getCourseById(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [created] = await db.insert(courses).values(course).returning();
    return created;
  }

  async getAllLearningPaths(): Promise<LearningPath[]> {
    return db.select().from(learningPaths);
  }

  async getLearningPathById(id: number): Promise<LearningPath | undefined> {
    const [path] = await db.select().from(learningPaths).where(eq(learningPaths.id, id));
    return path || undefined;
  }

  async createLearningPath(path: InsertLearningPath): Promise<LearningPath> {
    const [created] = await db.insert(learningPaths).values(path).returning();
    return created;
  }

  async getAllHardwareComponents(): Promise<HardwareComponent[]> {
    return db.select().from(hardwareComponents);
  }

  async getHardwareComponentById(id: number): Promise<HardwareComponent | undefined> {
    const [component] = await db.select().from(hardwareComponents).where(eq(hardwareComponents.id, id));
    return component || undefined;
  }

  async createHardwareComponent(component: InsertHardwareComponent): Promise<HardwareComponent> {
    const [created] = await db.insert(hardwareComponents).values(component).returning();
    return created;
  }

  async getAllSpecializations(): Promise<Specialization[]> {
    return db.select().from(specializations);
  }

  async getSpecializationById(id: number): Promise<Specialization | undefined> {
    const [spec] = await db.select().from(specializations).where(eq(specializations.id, id));
    return spec || undefined;
  }

  async createSpecialization(spec: InsertSpecialization): Promise<Specialization> {
    const [created] = await db.insert(specializations).values(spec).returning();
    return created;
  }

  async getAllSections(type?: string): Promise<AdditionalSection[]> {
    if (type) {
      return db.select().from(additionalSections).where(eq(additionalSections.type, type));
    }
    return db.select().from(additionalSections);
  }

  async getSectionById(id: number): Promise<AdditionalSection | undefined> {
    const [section] = await db.select().from(additionalSections).where(eq(additionalSections.id, id));
    return section || undefined;
  }

  async createSection(section: InsertAdditionalSection): Promise<AdditionalSection> {
    const [created] = await db.insert(additionalSections).values(section).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
