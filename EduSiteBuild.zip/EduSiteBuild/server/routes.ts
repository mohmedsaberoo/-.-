import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/languages", async (req, res) => {
    try {
      const languages = await storage.getAllLanguages();
      res.json(languages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch languages" });
    }
  });

  app.get("/api/languages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const language = await storage.getLanguageById(id);
      if (!language) {
        return res.status(404).json({ error: "Language not found" });
      }
      res.json(language);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch language" });
    }
  });

  app.get("/api/questions", async (req, res) => {
    try {
      const questions = await storage.getAllQuestions();
      res.json(questions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch questions" });
    }
  });

  app.get("/api/questions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const question = await storage.getQuestionById(id);
      if (!question) {
        return res.status(404).json({ error: "Question not found" });
      }
      res.json(question);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch question" });
    }
  });

  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProjectById(id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch courses" });
    }
  });

  app.get("/api/courses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const course = await storage.getCourseById(id);
      if (!course) {
        return res.status(404).json({ error: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch course" });
    }
  });

  app.get("/api/learning-paths", async (req, res) => {
    try {
      const paths = await storage.getAllLearningPaths();
      res.json(paths);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch learning paths" });
    }
  });

  app.get("/api/learning-paths/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const path = await storage.getLearningPathById(id);
      if (!path) {
        return res.status(404).json({ error: "Learning path not found" });
      }
      res.json(path);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch learning path" });
    }
  });

  app.get("/api/hardware", async (req, res) => {
    try {
      const components = await storage.getAllHardwareComponents();
      res.json(components);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch hardware components" });
    }
  });

  app.get("/api/hardware/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const component = await storage.getHardwareComponentById(id);
      if (!component) {
        return res.status(404).json({ error: "Hardware component not found" });
      }
      res.json(component);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch hardware component" });
    }
  });

  app.get("/api/specializations", async (req, res) => {
    try {
      const specializations = await storage.getAllSpecializations();
      res.json(specializations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch specializations" });
    }
  });

  app.get("/api/specializations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const specialization = await storage.getSpecializationById(id);
      if (!specialization) {
        return res.status(404).json({ error: "Specialization not found" });
      }
      res.json(specialization);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch specialization" });
    }
  });

  app.get("/api/sections", async (req, res) => {
    try {
      const type = req.query.type as string | undefined;
      const sections = await storage.getAllSections(type);
      res.json(sections);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sections" });
    }
  });

  app.get("/api/sections/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const section = await storage.getSectionById(id);
      if (!section) {
        return res.status(404).json({ error: "Section not found" });
      }
      res.json(section);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch section" });
    }
  });

  return httpServer;
}
