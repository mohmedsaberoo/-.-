import { db } from "./db";
import { 
  programmingLanguages, 
  questions, 
  projects, 
  courses, 
  learningPaths, 
  hardwareComponents, 
  specializations,
  additionalSections 
} from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  await db.insert(programmingLanguages).values([
    {
      name: "Python",
      nameAr: "بايثون",
      description: "لغة برمجة عالية المستوى سهلة التعلم، تُستخدم في الذكاء الاصطناعي وتحليل البيانات وتطوير الويب.",
      useCases: ["الذكاء الاصطناعي", "تحليل البيانات", "تطوير الويب", "الأتمتة", "تعلم الآلة"],
      features: ["سهلة التعلم والقراءة", "مكتبات ضخمة", "مجتمع نشط", "متعددة الاستخدامات", "مفسرة وليست مترجمة"],
      workingMethod: "بايثون لغة مفسرة، مما يعني أن الكود يُنفذ سطراً بسطر دون الحاجة لتحويله إلى لغة الآلة أولاً. هذا يجعلها سهلة التطوير والاختبار.",
      realLifeExamples: ["Netflix", "Instagram", "Spotify", "Google", "NASA"],
      codeSnippet: `# مثال على برنامج بايثون بسيط
def greet(name):
    return f"مرحباً {name}!"

names = ["أحمد", "سارة", "محمد"]
for name in names:
    print(greet(name))`,
      bestPractices: ["استخدم أسماء متغيرات واضحة", "اتبع معايير PEP 8", "اكتب توثيقاً للكود", "استخدم البيئات الافتراضية"],
      learningTips: ["ابدأ بالأساسيات", "مارس كتابة الكود يومياً", "أنشئ مشاريع صغيرة", "انضم لمجتمعات المطورين"],
      icon: "python",
      color: "#3776AB"
    },
    {
      name: "JavaScript",
      nameAr: "جافاسكريبت",
      description: "لغة برمجة أساسية للويب، تُستخدم لإضافة التفاعلية لصفحات الويب وبناء تطبيقات كاملة.",
      useCases: ["تطوير الواجهات الأمامية", "تطوير الخوادم", "تطبيقات الموبايل", "تطوير الألعاب", "تطبيقات سطح المكتب"],
      features: ["تعمل في المتصفح", "غير متزامنة", "كائنية التوجه", "ديناميكية النوع", "متعددة النماذج"],
      workingMethod: "جافاسكريبت تُفسر في المتصفح مباشرة، وتستخدم محركات مثل V8 لتحويلها إلى كود الآلة. يمكن استخدامها في الخادم عبر Node.js.",
      realLifeExamples: ["Facebook", "Twitter", "Netflix", "Uber", "Airbnb"],
      codeSnippet: `// مثال على كود جافاسكريبت
const greeting = (name) => {
  return \`مرحباً \${name}!\`;
};

const names = ["علي", "فاطمة", "عمر"];
names.forEach(name => {
  console.log(greeting(name));
});`,
      bestPractices: ["استخدم const و let بدلاً من var", "تجنب المتغيرات العامة", "استخدم TypeScript للمشاريع الكبيرة", "اختبر كودك"],
      learningTips: ["تعلم أساسيات HTML و CSS أولاً", "افهم الـ DOM جيداً", "تعلم ES6+", "جرب إطارات عمل مثل React"],
      icon: "javascript",
      color: "#F7DF1E"
    },
    {
      name: "TypeScript",
      nameAr: "تايب سكريبت",
      description: "نسخة محسنة من جافاسكريبت تضيف الأنواع الثابتة، مما يجعل الكود أكثر أماناً وقابلية للصيانة.",
      useCases: ["تطبيقات المؤسسات", "تطوير Angular", "تطوير React", "Node.js", "تطبيقات كبيرة"],
      features: ["أنواع ثابتة", "دعم IDE ممتاز", "متوافقة مع JavaScript", "أمان الأنواع", "توثيق ذاتي"],
      workingMethod: "TypeScript تُترجم إلى JavaScript قبل التنفيذ. المترجم يتحقق من الأنواع ويكتشف الأخطاء قبل وقت التشغيل.",
      realLifeExamples: ["Microsoft Teams", "Slack", "Airbnb", "Bloomberg", "Asana"],
      codeSnippet: `// مثال على كود TypeScript
interface Person {
  name: string;
  age: number;
}

const greet = (person: Person): string => {
  return \`مرحباً \${person.name}، عمرك \${person.age} سنة\`;
};

const user: Person = { name: "محمد", age: 25 };
console.log(greet(user));`,
      bestPractices: ["عرّف الأنواع بوضوح", "استخدم الواجهات", "تجنب any", "فعّل الوضع الصارم"],
      learningTips: ["تعلم JavaScript أولاً", "ابدأ بالأنواع الأساسية", "استخدم محرر يدعم TypeScript", "اقرأ الوثائق الرسمية"],
      icon: "typescript",
      color: "#3178C6"
    },
    {
      name: "Java",
      nameAr: "جافا",
      description: "لغة برمجة قوية ومستقرة تُستخدم في تطوير تطبيقات المؤسسات وتطبيقات Android.",
      useCases: ["تطبيقات Android", "تطبيقات المؤسسات", "أنظمة البنوك", "الخوادم", "البيانات الضخمة"],
      features: ["مستقلة عن المنصة", "كائنية التوجه", "آمنة", "مستقرة", "أداء عالي"],
      workingMethod: "Java تُترجم إلى bytecode يعمل على JVM (الآلة الافتراضية)، مما يجعلها تعمل على أي نظام به JVM.",
      realLifeExamples: ["Android", "Amazon", "LinkedIn", "Netflix", "Uber"],
      codeSnippet: `// مثال على كود Java
public class Main {
    public static void main(String[] args) {
        String[] names = {"خالد", "منى", "ياسر"};
        for (String name : names) {
            System.out.println("مرحباً " + name + "!");
        }
    }
}`,
      bestPractices: ["اتبع معايير التسمية", "استخدم التصميم الكائني", "اكتب اختبارات", "وثق كودك"],
      learningTips: ["تعلم أساسيات OOP", "مارس حل المشكلات", "ابنِ مشاريع صغيرة", "تعلم إطارات العمل مثل Spring"],
      icon: "java",
      color: "#ED8B00"
    },
    {
      name: "C++",
      nameAr: "سي بلس بلس",
      description: "لغة برمجة قوية تُستخدم في تطوير الأنظمة والألعاب والتطبيقات عالية الأداء.",
      useCases: ["تطوير الألعاب", "أنظمة التشغيل", "المتصفحات", "قواعد البيانات", "الروبوتات"],
      features: ["أداء عالي جداً", "تحكم بالذاكرة", "كائنية التوجه", "قوالب", "متعددة النماذج"],
      workingMethod: "C++ تُترجم مباشرة إلى كود الآلة، مما يمنحها أداءً عالياً جداً وتحكماً كاملاً بالعتاد.",
      realLifeExamples: ["Unreal Engine", "Chrome", "Windows", "Adobe Software", "MySQL"],
      codeSnippet: `// مثال على كود C++
#include <iostream>
#include <vector>
#include <string>

int main() {
    std::vector<std::string> names = {"سلمى", "رامي", "هند"};
    for (const auto& name : names) {
        std::cout << "مرحباً " << name << "!" << std::endl;
    }
    return 0;
}`,
      bestPractices: ["تجنب تسرب الذاكرة", "استخدم المؤشرات الذكية", "اتبع RAII", "اكتب كوداً آمناً"],
      learningTips: ["ابدأ بـ C أولاً", "افهم المؤشرات جيداً", "تعلم إدارة الذاكرة", "مارس كثيراً"],
      icon: "cpp",
      color: "#00599C"
    }
  ]).onConflictDoNothing();

  await db.insert(questions).values([
    {
      questionText: "ما هي لغة البرمجة الأكثر استخداماً في تطوير الواجهات الأمامية للويب؟",
      choices: ["Python", "JavaScript", "Java", "C++"],
      correctAnswer: 1,
      explanation: "JavaScript هي اللغة الأساسية لتطوير الواجهات الأمامية، وتعمل مباشرة في المتصفح لإضافة التفاعلية لصفحات الويب.",
      category: "لغات البرمجة",
      difficulty: "easy"
    },
    {
      questionText: "ما هو الفرق الرئيسي بين الهاردوير والسوفتوير؟",
      choices: ["السوفتوير أغلى من الهاردوير", "الهاردوير هو الأجزاء المادية والسوفتوير هو البرامج", "لا يوجد فرق بينهما", "الهاردوير يعمل بدون كهرباء"],
      correctAnswer: 1,
      explanation: "الهاردوير يشمل جميع الأجزاء المادية الملموسة في الكمبيوتر مثل المعالج والذاكرة، بينما السوفتوير هو البرامج والتطبيقات التي تعمل على هذه الأجزاء.",
      category: "أساسيات",
      difficulty: "easy"
    },
    {
      questionText: "ما هي وظيفة المعالج (CPU) في الكمبيوتر؟",
      choices: ["تخزين البيانات بشكل دائم", "عرض الصور على الشاشة", "تنفيذ العمليات الحسابية والمنطقية", "الاتصال بالإنترنت"],
      correctAnswer: 2,
      explanation: "المعالج (CPU) هو عقل الكمبيوتر، ويقوم بتنفيذ جميع العمليات الحسابية والمنطقية ومعالجة البيانات.",
      category: "الهاردوير",
      difficulty: "easy"
    },
    {
      questionText: "ما هو الناتج من الكود التالي: console.log(2 + '2')؟",
      choices: ["4", "22", "NaN", "خطأ"],
      correctAnswer: 1,
      explanation: "في JavaScript، عند جمع رقم مع نص، يتم تحويل الرقم إلى نص ويتم دمجهما، لذا 2 + '2' = '22'.",
      category: "جافاسكريبت",
      difficulty: "medium"
    },
    {
      questionText: "ما هي الذاكرة العشوائية (RAM)؟",
      choices: ["ذاكرة تخزين دائمة", "ذاكرة تخزين مؤقتة سريعة", "معالج الرسوميات", "نوع من الأقراص الصلبة"],
      correctAnswer: 1,
      explanation: "RAM هي ذاكرة مؤقتة سريعة جداً تستخدم لتخزين البيانات التي يحتاجها المعالج أثناء تشغيل البرامج، وتُفرغ عند إيقاف الجهاز.",
      category: "الهاردوير",
      difficulty: "easy"
    },
    {
      questionText: "ما هو TypeScript؟",
      choices: ["نظام تشغيل", "قاعدة بيانات", "نسخة محسنة من JavaScript مع أنواع ثابتة", "لغة برمجة منفصلة تماماً"],
      correctAnswer: 2,
      explanation: "TypeScript هي لغة برمجة طورتها Microsoft، وهي عبارة عن JavaScript مع إضافة نظام الأنواع الثابتة لجعل الكود أكثر أماناً.",
      category: "لغات البرمجة",
      difficulty: "medium"
    },
    {
      questionText: "ما هي وظيفة Git؟",
      choices: ["تحرير النصوص", "إدارة الإصدارات والتعاون", "تصميم الواجهات", "اختبار الكود"],
      correctAnswer: 1,
      explanation: "Git هو نظام للتحكم بالإصدارات يسمح للمطورين بتتبع التغييرات في الكود والتعاون مع فرق أخرى بسهولة.",
      category: "أدوات التطوير",
      difficulty: "easy"
    },
    {
      questionText: "ما هو React؟",
      choices: ["لغة برمجة", "قاعدة بيانات", "مكتبة JavaScript لبناء واجهات المستخدم", "نظام تشغيل"],
      correctAnswer: 2,
      explanation: "React هي مكتبة JavaScript طورتها Facebook لبناء واجهات مستخدم تفاعلية وقابلة لإعادة الاستخدام.",
      category: "إطارات العمل",
      difficulty: "easy"
    },
    {
      questionText: "ما هو الفرق بين == و === في JavaScript؟",
      choices: ["لا يوجد فرق", "=== تقارن القيمة والنوع، == تقارن القيمة فقط", "== أسرع من ===", "=== للأرقام فقط"],
      correctAnswer: 1,
      explanation: "=== (المساواة الصارمة) تقارن القيمة والنوع معاً، بينما == (المساواة الفضفاضة) تقارن القيمة فقط وقد تقوم بتحويل الأنواع.",
      category: "جافاسكريبت",
      difficulty: "medium"
    },
    {
      questionText: "ما هي لغة Python المستخدمة بشكل رئيسي؟",
      choices: ["تطوير iOS فقط", "تصميم الشعارات", "الذكاء الاصطناعي وتحليل البيانات", "تصميم الدوائر الإلكترونية"],
      correctAnswer: 2,
      explanation: "Python تُستخدم بشكل واسع في مجالات الذكاء الاصطناعي، تعلم الآلة، تحليل البيانات، والأتمتة بفضل مكتباتها الغنية وسهولة تعلمها.",
      category: "لغات البرمجة",
      difficulty: "easy"
    },
    {
      questionText: "ما هي وظيفة كرت الشاشة (GPU)؟",
      choices: ["تخزين البيانات", "معالجة الرسوميات والصور", "الاتصال بالشبكة", "تبريد الجهاز"],
      correctAnswer: 1,
      explanation: "GPU متخصص في معالجة الرسوميات والعمليات المتوازية، ويُستخدم في الألعاب، تحرير الفيديو، والذكاء الاصطناعي.",
      category: "الهاردوير",
      difficulty: "easy"
    },
    {
      questionText: "ما هو API؟",
      choices: ["نوع من البرمجيات الخبيثة", "واجهة برمجة التطبيقات للتواصل بين البرامج", "نظام تشغيل", "لغة برمجة"],
      correctAnswer: 1,
      explanation: "API (واجهة برمجة التطبيقات) هي مجموعة من القواعد والبروتوكولات التي تسمح للبرامج المختلفة بالتواصل وتبادل البيانات.",
      category: "مفاهيم البرمجة",
      difficulty: "medium"
    },
    {
      questionText: "ما هو الناتج من [1, 2, 3].map(x => x * 2)؟",
      choices: ["[1, 2, 3]", "[2, 4, 6]", "6", "خطأ"],
      correctAnswer: 1,
      explanation: "دالة map تطبق الدالة المعطاة على كل عنصر في المصفوفة وتُرجع مصفوفة جديدة بالنتائج، لذا كل عنصر يُضرب في 2.",
      category: "جافاسكريبت",
      difficulty: "medium"
    },
    {
      questionText: "ما هو Node.js؟",
      choices: ["متصفح ويب", "بيئة تشغيل JavaScript على الخادم", "قاعدة بيانات", "نظام تشغيل"],
      correctAnswer: 1,
      explanation: "Node.js هو بيئة تشغيل تسمح بتشغيل JavaScript خارج المتصفح، مما يمكّن من استخدامها في تطوير الخوادم.",
      category: "إطارات العمل",
      difficulty: "easy"
    },
    {
      questionText: "ما هي قاعدة البيانات؟",
      choices: ["برنامج لتحرير الصور", "نظام لتنظيم وتخزين البيانات", "نوع من المعالجات", "كابل للاتصال"],
      correctAnswer: 1,
      explanation: "قاعدة البيانات هي نظام منظم لتخزين واسترجاع وإدارة البيانات بطريقة فعالة وآمنة.",
      category: "قواعد البيانات",
      difficulty: "easy"
    },
    {
      questionText: "ما هو HTML؟",
      choices: ["لغة برمجة", "لغة ترميز لبناء هيكل صفحات الويب", "قاعدة بيانات", "بروتوكول شبكة"],
      correctAnswer: 1,
      explanation: "HTML (لغة ترميز النص التشعبي) تُستخدم لبناء الهيكل الأساسي لصفحات الويب وتحديد العناصر المختلفة فيها.",
      category: "تطوير الويب",
      difficulty: "easy"
    },
    {
      questionText: "ما هو CSS؟",
      choices: ["لغة برمجة", "لغة تنسيق لتصميم مظهر صفحات الويب", "نظام ملفات", "بروتوكول أمان"],
      correctAnswer: 1,
      explanation: "CSS (أوراق الأنماط المتتالية) تُستخدم لتنسيق وتصميم مظهر صفحات الويب بما في ذلك الألوان والخطوط والتخطيط.",
      category: "تطوير الويب",
      difficulty: "easy"
    },
    {
      questionText: "ما هو الفرق بين SSD و HDD؟",
      choices: ["SSD أبطأ من HDD", "SSD يستخدم شرائح ذاكرة وHDD يستخدم أقراص دوارة", "لا يوجد فرق", "HDD أصغر حجماً"],
      correctAnswer: 1,
      explanation: "SSD يستخدم شرائح ذاكرة فلاش وهو أسرع وأكثر متانة، بينما HDD يستخدم أقراص مغناطيسية دوارة وهو أبطأ لكنه أرخص.",
      category: "الهاردوير",
      difficulty: "medium"
    },
    {
      questionText: "ما هي async/await في JavaScript؟",
      choices: ["طريقة لإنشاء المتغيرات", "صيغة للتعامل مع العمليات غير المتزامنة", "نوع من الحلقات", "طريقة لتعريف الدوال"],
      correctAnswer: 1,
      explanation: "async/await هي صيغة حديثة في JavaScript للتعامل مع العمليات غير المتزامنة بطريقة أسهل وأكثر قراءة من الـ Promises.",
      category: "جافاسكريبت",
      difficulty: "advanced"
    },
    {
      questionText: "ما هو مفهوم OOP؟",
      choices: ["أداة لتحرير الكود", "البرمجة كائنية التوجه", "نوع من قواعد البيانات", "بروتوكول شبكة"],
      correctAnswer: 1,
      explanation: "OOP (البرمجة كائنية التوجه) هي نمط برمجي يعتمد على تنظيم الكود في كائنات تحتوي على بيانات وسلوكيات.",
      category: "مفاهيم البرمجة",
      difficulty: "medium"
    },
    {
      questionText: "ما هو Docker؟",
      choices: ["لغة برمجة", "منصة لحاويات البرمجيات", "متصفح ويب", "نظام تشغيل"],
      correctAnswer: 1,
      explanation: "Docker هو منصة تسمح بتعبئة التطبيقات في حاويات معزولة تتضمن كل ما تحتاجه للعمل بشكل مستقل.",
      category: "أدوات التطوير",
      difficulty: "advanced"
    },
    {
      questionText: "ما هو الـ Framework؟",
      choices: ["نوع من الأجهزة", "هيكل برمجي جاهز لبناء التطبيقات", "متصفح ويب", "لغة برمجة"],
      correctAnswer: 1,
      explanation: "Framework هو إطار عمل يوفر هيكلاً وأدوات جاهزة لتسهيل وتسريع عملية تطوير التطبيقات.",
      category: "مفاهيم البرمجة",
      difficulty: "easy"
    },
    {
      questionText: "ما هي اللوحة الأم (Motherboard)؟",
      choices: ["نوع من الذاكرة", "اللوحة الرئيسية التي تربط جميع مكونات الكمبيوتر", "معالج خاص", "وحدة تبريد"],
      correctAnswer: 1,
      explanation: "اللوحة الأم هي اللوحة الإلكترونية الرئيسية التي تربط جميع مكونات الكمبيوتر ببعضها وتسمح لها بالتواصل.",
      category: "الهاردوير",
      difficulty: "easy"
    },
    {
      questionText: "ما هو الـ Responsive Design؟",
      choices: ["تصميم سريع", "تصميم يتكيف مع أحجام الشاشات المختلفة", "تصميم ملون", "تصميم ثلاثي الأبعاد"],
      correctAnswer: 1,
      explanation: "Responsive Design هو نهج في تصميم الويب يجعل الصفحات تتكيف تلقائياً مع أحجام الشاشات المختلفة من الهواتف إلى أجهزة الكمبيوتر.",
      category: "تطوير الويب",
      difficulty: "easy"
    },
    {
      questionText: "ما هو الـ Algorithm؟",
      choices: ["نوع من البرمجيات الخبيثة", "سلسلة من الخطوات لحل مشكلة", "لغة برمجة", "جهاز كمبيوتر"],
      correctAnswer: 1,
      explanation: "الخوارزمية هي مجموعة من الخطوات المنطقية والمتسلسلة لحل مشكلة معينة أو تنفيذ مهمة محددة.",
      category: "مفاهيم البرمجة",
      difficulty: "easy"
    }
  ]).onConflictDoNothing();

  await db.insert(projects).values([
    {
      title: "Calculator",
      titleAr: "حاسبة إلكترونية",
      description: "حاسبة تفاعلية متكاملة تدعم العمليات الحسابية الأساسية والمتقدمة مع واجهة مستخدم عصرية وجذابة.",
      technologies: ["JavaScript", "HTML", "CSS", "React"],
      category: "أدوات",
      features: ["العمليات الأساسية", "التاريخ والذاكرة", "الوضع العلمي", "تصميم متجاوب"],
      imagePath: null,
      demoUrl: null
    },
    {
      title: "Todo App",
      titleAr: "تطبيق المهام",
      description: "تطبيق لإدارة المهام اليومية مع إمكانية إضافة وحذف وتعديل المهام وتحديد أولوياتها.",
      technologies: ["TypeScript", "React", "Tailwind CSS", "LocalStorage"],
      category: "إنتاجية",
      features: ["إضافة مهام", "تعديل وحذف", "تصنيف بالأولوية", "حفظ محلي"],
      imagePath: null,
      demoUrl: null
    },
    {
      title: "Weather App",
      titleAr: "تطبيق الطقس",
      description: "تطبيق لعرض حالة الطقس الحالية والتوقعات لمختلف المدن حول العالم باستخدام API خارجي.",
      technologies: ["JavaScript", "API Integration", "CSS Grid", "Geolocation"],
      category: "أدوات",
      features: ["الطقس الحالي", "توقعات أسبوعية", "البحث بالمدينة", "تحديد الموقع"],
      imagePath: null,
      demoUrl: null
    },
    {
      title: "Quiz Game",
      titleAr: "لعبة الأسئلة",
      description: "لعبة أسئلة تفاعلية مع عدة مستويات صعوبة ونظام نقاط وترتيب اللاعبين.",
      technologies: ["React", "TypeScript", "Framer Motion", "State Management"],
      category: "ألعاب",
      features: ["مستويات متعددة", "نظام نقاط", "تأثيرات حركية", "إحصائيات"],
      imagePath: null,
      demoUrl: null
    },
    {
      title: "Portfolio Website",
      titleAr: "موقع شخصي",
      description: "موقع شخصي احترافي لعرض الأعمال والمهارات مع تصميم عصري ومتجاوب.",
      technologies: ["React", "Tailwind CSS", "Framer Motion", "TypeScript"],
      category: "مواقع",
      features: ["تصميم متجاوب", "تأثيرات حركية", "نموذج تواصل", "معرض أعمال"],
      imagePath: null,
      demoUrl: null
    }
  ]).onConflictDoNothing();

  await db.insert(courses).values([
    {
      title: "JavaScript Fundamentals",
      titleAr: "أساسيات جافاسكريبت",
      description: "كورس شامل لتعلم أساسيات لغة JavaScript من الصفر حتى الاحتراف، يغطي جميع المفاهيم الأساسية والمتقدمة.",
      status: "coming_soon",
      videoUrls: [],
      thumbnailPath: null,
      duration: "10 ساعات",
      level: "beginner"
    },
    {
      title: "React Development",
      titleAr: "تطوير React",
      description: "تعلم بناء تطبيقات ويب حديثة باستخدام React مع أفضل الممارسات وأحدث التقنيات.",
      status: "coming_soon",
      videoUrls: [],
      thumbnailPath: null,
      duration: "15 ساعة",
      level: "intermediate"
    },
    {
      title: "Python for Beginners",
      titleAr: "بايثون للمبتدئين",
      description: "كورس متكامل لتعلم Python من البداية مع التركيز على الجانب العملي والمشاريع التطبيقية.",
      status: "coming_soon",
      videoUrls: [],
      thumbnailPath: null,
      duration: "12 ساعة",
      level: "beginner"
    },
    {
      title: "Full Stack Development",
      titleAr: "التطوير الشامل",
      description: "تعلم تطوير تطبيقات ويب كاملة من الواجهة الأمامية إلى الخادم وقواعد البيانات.",
      status: "coming_soon",
      videoUrls: [],
      thumbnailPath: null,
      duration: "25 ساعة",
      level: "advanced"
    }
  ]).onConflictDoNothing();

  await db.insert(learningPaths).values([
    {
      title: "Frontend Developer",
      titleAr: "مطور واجهات أمامية",
      description: "مسار تعليمي شامل لتصبح مطور واجهات أمامية محترف",
      steps: [
        { order: 1, title: "تعلم HTML", description: "أساسيات بناء صفحات الويب", icon: "code" },
        { order: 2, title: "تعلم CSS", description: "تنسيق وتصميم الصفحات", icon: "code" },
        { order: 3, title: "تعلم JavaScript", description: "إضافة التفاعلية للصفحات", icon: "code" },
        { order: 4, title: "تعلم React", description: "بناء تطبيقات حديثة", icon: "rocket" },
        { order: 5, title: "بناء مشاريع", description: "تطبيق ما تعلمته", icon: "target" }
      ],
      icon: "code",
      color: "#00d4ff",
      estimatedTime: "6 أشهر"
    },
    {
      title: "Backend Developer",
      titleAr: "مطور خوادم",
      description: "مسار تعليمي لتصبح مطور خوادم وواجهات برمجية",
      steps: [
        { order: 1, title: "تعلم لغة برمجة", description: "JavaScript أو Python", icon: "code" },
        { order: 2, title: "تعلم Node.js", description: "بناء خوادم بـ JavaScript", icon: "code" },
        { order: 3, title: "قواعد البيانات", description: "SQL و NoSQL", icon: "brain" },
        { order: 4, title: "APIs", description: "بناء واجهات برمجية", icon: "rocket" },
        { order: 5, title: "الأمان", description: "تأمين التطبيقات", icon: "target" }
      ],
      icon: "brain",
      color: "#9d4edd",
      estimatedTime: "8 أشهر"
    },
    {
      title: "Data Scientist",
      titleAr: "عالم بيانات",
      description: "مسار لتعلم علم البيانات والذكاء الاصطناعي",
      steps: [
        { order: 1, title: "تعلم Python", description: "أساسيات البرمجة", icon: "code" },
        { order: 2, title: "الرياضيات والإحصاء", description: "الأساسيات المطلوبة", icon: "brain" },
        { order: 3, title: "تحليل البيانات", description: "Pandas و NumPy", icon: "code" },
        { order: 4, title: "تعلم الآلة", description: "Scikit-learn", icon: "brain" },
        { order: 5, title: "التعلم العميق", description: "TensorFlow", icon: "rocket" }
      ],
      icon: "brain",
      color: "#00ffff",
      estimatedTime: "12 شهر"
    }
  ]).onConflictDoNothing();

  await db.insert(hardwareComponents).values([
    {
      name: "CPU",
      nameAr: "المعالج المركزي",
      description: "عقل الكمبيوتر المسؤول عن تنفيذ جميع العمليات الحسابية والمنطقية",
      function: "يقوم بمعالجة جميع البيانات والتعليمات، ويتحكم في عمل باقي مكونات الكمبيوتر",
      specifications: ["عدد الأنوية", "سرعة الساعة (GHz)", "ذاكرة التخزين المؤقت", "معمارية النانومتر"],
      icon: "processor",
      category: "processor"
    },
    {
      name: "GPU",
      nameAr: "معالج الرسوميات",
      description: "معالج متخصص في عمليات الرسوميات والحسابات المتوازية",
      function: "معالجة الصور والفيديو والرسوميات ثلاثية الأبعاد، ويستخدم أيضاً في الذكاء الاصطناعي",
      specifications: ["ذاكرة VRAM", "عرض النطاق الترددي", "أنوية CUDA/Stream", "استهلاك الطاقة"],
      icon: "display",
      category: "display"
    },
    {
      name: "RAM",
      nameAr: "الذاكرة العشوائية",
      description: "ذاكرة مؤقتة سريعة جداً تستخدم لتخزين البيانات النشطة",
      function: "تخزين البيانات والبرامج المستخدمة حالياً للوصول السريع من قبل المعالج",
      specifications: ["السعة (GB)", "السرعة (MHz)", "النوع (DDR4/DDR5)", "التوقيتات"],
      icon: "memory",
      category: "memory"
    },
    {
      name: "SSD",
      nameAr: "قرص التخزين الصلب",
      description: "وحدة تخزين دائمة سريعة تعتمد على شرائح الذاكرة",
      function: "تخزين نظام التشغيل والبرامج والملفات بشكل دائم مع سرعة قراءة وكتابة عالية",
      specifications: ["السعة", "سرعة القراءة", "سرعة الكتابة", "نوع الواجهة (SATA/NVMe)"],
      icon: "storage",
      category: "storage"
    },
    {
      name: "Motherboard",
      nameAr: "اللوحة الأم",
      description: "اللوحة الرئيسية التي تربط جميع مكونات الكمبيوتر",
      function: "توفير التوصيلات والمسارات لنقل البيانات بين جميع المكونات",
      specifications: ["حجم الفورم", "شريحة الإدخال/الإخراج", "مقابس التوسعة", "دعم المعالج"],
      icon: "motherboard",
      category: "motherboard"
    },
    {
      name: "PSU",
      nameAr: "مزود الطاقة",
      description: "وحدة تحويل وتوزيع الطاقة الكهربائية لمكونات الكمبيوتر",
      function: "تحويل التيار المتناوب إلى تيار مستمر وتوزيعه على المكونات بالجهد المناسب",
      specifications: ["القدرة (وات)", "الكفاءة (80+ Rating)", "عدد الكابلات", "نوع (معياري/ثابت)"],
      icon: "power",
      category: "power"
    },
    {
      name: "CPU Cooler",
      nameAr: "مبرد المعالج",
      description: "نظام تبريد للحفاظ على درجة حرارة المعالج مناسبة",
      function: "تبديد الحرارة الناتجة عن المعالج للحفاظ على أدائه واستقراره",
      specifications: ["نوع التبريد (هوائي/مائي)", "سرعة المروحة", "مستوى الضوضاء", "TDP المدعوم"],
      icon: "cooling",
      category: "cooling"
    },
    {
      name: "Monitor",
      nameAr: "الشاشة",
      description: "جهاز عرض المخرجات المرئية من الكمبيوتر",
      function: "عرض الصور والفيديو وواجهة المستخدم للتفاعل مع الكمبيوتر",
      specifications: ["الدقة", "معدل التحديث", "نوع اللوحة (IPS/VA/TN)", "زمن الاستجابة"],
      icon: "display",
      category: "display"
    }
  ]).onConflictDoNothing();

  await db.insert(specializations).values([
    {
      title: "Frontend Development",
      titleAr: "تطوير الواجهات الأمامية",
      description: "بناء واجهات مستخدم جذابة وتفاعلية باستخدام أحدث التقنيات",
      skills: ["HTML/CSS", "JavaScript", "React", "TypeScript", "Tailwind CSS", "Responsive Design"],
      icon: "frontend",
      color: "#00d4ff"
    },
    {
      title: "Backend Development",
      titleAr: "تطوير الخوادم",
      description: "بناء خوادم وواجهات برمجية قوية وآمنة",
      skills: ["Node.js", "Express", "APIs", "قواعد البيانات", "الأمان", "Docker"],
      icon: "backend",
      color: "#9d4edd"
    },
    {
      title: "Database Management",
      titleAr: "إدارة قواعد البيانات",
      description: "تصميم وإدارة قواعد البيانات بكفاءة",
      skills: ["PostgreSQL", "MongoDB", "Redis", "تحسين الأداء", "النسخ الاحتياطي"],
      icon: "database",
      color: "#00ffff"
    },
    {
      title: "UI/UX Design",
      titleAr: "تصميم الواجهات",
      description: "تصميم تجارب مستخدم سلسة وواجهات جذابة",
      skills: ["Figma", "التصميم المتجاوب", "تجربة المستخدم", "نظام الألوان", "التايبوغرافي"],
      icon: "design",
      color: "#ff6b6b"
    }
  ]).onConflictDoNothing();

  await db.insert(additionalSections).values([
    {
      title: "Resources",
      titleAr: "الموارد التعليمية",
      description: "مجموعة من المصادر المفيدة للتعلم",
      content: [
        { title: "MDN Web Docs", description: "مرجع شامل لتقنيات الويب", url: "https://developer.mozilla.org", type: "article" },
        { title: "freeCodeCamp", description: "منصة تعلم البرمجة المجانية", url: "https://freecodecamp.org", type: "course" },
        { title: "YouTube Programming", description: "قنوات تعليمية على يوتيوب", url: "https://youtube.com", type: "video" }
      ],
      icon: "layers",
      type: "resources"
    },
    {
      title: "Tools",
      titleAr: "أدوات المطور",
      description: "أدوات مفيدة للمطورين",
      content: [
        { name: "VS Code", description: "محرر أكواد قوي ومجاني", url: "https://code.visualstudio.com", category: "development", free: true },
        { name: "Git", description: "نظام التحكم بالإصدارات", url: "https://git-scm.com", category: "development", free: true },
        { name: "Figma", description: "أداة تصميم الواجهات", url: "https://figma.com", category: "design", free: true },
        { name: "Postman", description: "اختبار واجهات APIs", url: "https://postman.com", category: "development", free: true }
      ],
      icon: "sparkles",
      type: "tools"
    }
  ]).onConflictDoNothing();

  console.log("Database seeded successfully!");
}

seed()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Error seeding database:", err);
    process.exit(1);
  });
