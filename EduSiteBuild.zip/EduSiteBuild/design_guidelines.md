# Design Guidelines: AI Cyber-Tech Educational Platform

## Design Approach
**User-Specified Aesthetic**: Dark AI cyber-tech interface with extreme futuristic robotics theme inspired by sci-fi cinematics and holographic interfaces.

## Visual Identity

### Color Palette
- **Base**: Deep dark backgrounds (#0a0a0f, #121218, #1a1a2e)
- **Neon Accents**: Electric blue (#00d4ff, #0099ff), cyber purple (#9d4edd, #c77dff), neon cyan (#00ffff, #7df9ff)
- **Glows**: Animated gradient borders cycling through blue/purple/cyan spectrum
- **Glass Effects**: Semi-transparent overlays with backdrop blur and neon edge lighting

### Typography
- **Primary Font**: Futuristic, tech-inspired sans-serif (Orbitron, Exo 2, or Rajdhani for headers)
- **Arabic Font**: Modern Arabic tech font (Cairo, Tajawal) maintaining sci-fi aesthetic
- **Hierarchy**: 
  - Hero titles: 48-72px with neon glow text-shadow
  - Section headers: 32-48px with animated gradient
  - Body text: 16-18px with high contrast (#e0e0e0)
  - Code blocks: Monospace (Fira Code) with syntax highlighting

### Layout System
- **Spacing**: Generous padding (py-16 to py-24) for breathing room between futuristic sections
- **Glass Cards**: p-8 rounded-xl with backdrop-blur-lg and border-2 neon glow
- **Grid Systems**: 
  - Programming languages: 2-column (md) to 3-column (lg) cards
  - Projects: Masonry/card grid with 2-4 columns responsive
  - Quiz: Single column centered with max-w-3xl
  - Hardware diagrams: Full-width interactive SVG sections

## Component Library

### Navigation
- **Header**: Fixed top navbar with semi-transparent dark glass, neon bottom border, animated hover states with glow effect
- **Links**: Arabic text with smooth hover transitions revealing neon underline scan animation
- **Mobile**: Hamburger menu with slide-in panel featuring particle effects

### Cards & Containers
- **Holographic Cards**: Dark glass background with animated rotating border gradient, hover lift effect (translateY(-4px)), subtle shadow glow
- **Project Cards**: Image overlay with neon frame, technology tags as pill badges with glow, "View Project" CTA with scanning line animation
- **Language Cards**: Icon/logo top, title with neon accent, expandable description with smooth height transition

### Interactive Elements
- **Buttons**: 
  - Primary: Solid neon background with pulse animation, glass morphism on hover
  - Secondary: Outlined neon border with fill animation on hover
  - Back buttons: Floating bottom-right with Arabic "الرجوع إلى الوراء", subtle glow
- **Quiz Options**: Radio-style cards with neon border activation, correct/incorrect state animations (green glow/red pulse)
- **Form Inputs**: Dark glass with neon focus border, placeholder text in dimmed cyan

### Background Animations (Canvas/CSS)
- **Layers**:
  1. Animated 3D grid with perspective depth
  2. Floating particles (50-100 elements) with varying speeds
  3. Scanning laser lines (horizontal/vertical sweeps)
  4. Robot arm silhouettes moving across viewport edges
  5. Rotating circuit patterns with glowing nodes
  6. Digital rain effect (Matrix-style) in background layer
- **Performance**: Use CSS transforms and will-change, canvas for complex animations, requestAnimationFrame for smooth 60fps

### Page-Specific Elements
- **Home Hero**: Full-viewport with centered content, animated robot silhouette background, "Start Learning" button with holographic frame
- **Hardware Diagrams**: Interactive SVG with hover tooltips, animated connection lines, labeled components with neon highlights
- **About Me**: Split bilingual layout (Arabic right/English left) with avatar image frame, animated social icons with glow
- **Learning Paths**: Vertical timeline with connected nodes, step cards sliding in on scroll, progress indicator lines
- **Courses**: Video placeholder cards with "سيتم التوفير قريبًا" in glowing holographic text

## Animations & Transitions
- **Page Entry**: Staggered fade-in + slide-up for sections (0.1s delay cascade)
- **Scroll Triggers**: Elements animate into view with parallax depth effect
- **Hover States**: Scale (1.02-1.05), glow intensity increase, border animation speed boost
- **Route Transitions**: Fade overlay with scanning line sweep between pages
- **Minimalism**: Focus animations on entry effects and background ambience, avoid distracting content animations

## Responsive Breakpoints
- Mobile (<768px): Single column, stacked navigation, reduced particle density, simplified animations
- Tablet (768-1024px): 2-column grids, compact spacing
- Desktop (>1024px): Full multi-column layouts, maximum animation detail, parallax effects

## Images
**Hero Section**: Large full-width background image showing robotic/AI workspace with holographic displays (use as backdrop with dark overlay 70% opacity)
**Project Thumbnails**: 16:9 aspect ratio screenshots/mockups with neon frame borders
**Hardware Section**: Component diagrams as SVG/images integrated into interactive UI
**Avatar**: Circular frame with animated neon orbital rings for About Me page