# Eleven Educational Platform

## Overview

Eleven is an Arabic-language educational platform focused on teaching programming, hardware, and technology. The platform features a futuristic dark AI cyber-tech aesthetic with neon accents, animated backgrounds, and holographic UI elements. It provides comprehensive learning resources including programming language tutorials, interactive quizzes, project showcases, learning paths, courses, and hardware explanations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state, local React state for UI
- **UI Framework**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom cyber-tech design system
- **Build Tool**: Vite for development and production builds

**Design System**:
- Custom color palette with neon accents (electric blue, cyber purple, neon cyan)
- Dark mode by default with glass morphism effects
- Animated gradients and particle effects using Canvas API
- RTL (right-to-left) support for Arabic content
- Custom fonts: Cairo/Tajawal for Arabic, Orbitron/Exo 2 for English headers

**Key Pages**:
- Home: Landing page with hero section and feature cards
- Languages: Programming language catalog with detailed explanations
- Hardware: Computer hardware components and explanations
- About: Creator profile and background
- Questions: Interactive quiz system with scoring
- Projects: Portfolio showcase with filtering
- Specializations: Technical specialization areas
- Learning Paths: Structured learning roadmaps
- Courses: Course catalog with video content
- Resources: Curated learning resources
- Tools: Developer tools and utilities

### Backend Architecture

**Framework**: Express.js with TypeScript
- **Runtime**: Node.js
- **ORM**: Drizzle ORM for type-safe database queries
- **Database Driver**: Neon Serverless (PostgreSQL)
- **API Design**: RESTful endpoints under `/api/*`

**Server Structure**:
- Entry point: `server/index.ts` - Express app setup with middleware
- Routes: `server/routes.ts` - API endpoint definitions
- Storage: `server/storage.ts` - Database abstraction layer
- Database: `server/db.ts` - Drizzle client configuration
- Static: `server/static.ts` - Serves built frontend in production
- Vite: `server/vite.ts` - Development server with HMR

**API Endpoints**:
- `GET /api/languages` - Fetch all programming languages
- `GET /api/languages/:id` - Fetch specific language
- `GET /api/questions` - Fetch all quiz questions
- `GET /api/questions/:id` - Fetch specific question
- `GET /api/projects` - Fetch all projects
- `GET /api/courses` - Fetch all courses
- `GET /api/learning-paths` - Fetch learning paths
- `GET /api/specializations` - Fetch specializations
- `GET /api/hardware-components` - Fetch hardware info
- `GET /api/sections/:type` - Fetch additional content sections

### Data Storage

**Database**: PostgreSQL via Neon Serverless
- Connection pooling for serverless environments
- WebSocket-based connections using `ws` library
- Schema migrations managed by Drizzle Kit

**Schema Design** (`shared/schema.ts`):
- `programming_languages`: Language details, code examples, best practices
- `questions`: Quiz questions with multiple choice answers and explanations
- `projects`: Portfolio projects with technologies and features
- `courses`: Educational courses with status and video URLs
- `learning_paths`: Structured learning roadmaps with steps
- `hardware_components`: Computer hardware explanations
- `specializations`: Technical specialization areas
- `additional_sections`: Flexible content for resources/tools pages

**Data Seeding**: `server/seed.ts` contains initial data population for all tables

### External Dependencies

**Core Libraries**:
- React ecosystem: React, React DOM, React Query
- Routing: Wouter (lightweight React router)
- UI Components: Radix UI primitives (40+ component packages)
- Styling: Tailwind CSS, PostCSS, Autoprefixer
- Forms: React Hook Form with Zod validation
- Database: Drizzle ORM, @neondatabase/serverless
- Date handling: date-fns
- Icons: Lucide React

**Development Tools**:
- TypeScript for type safety
- Vite for fast development and optimized builds
- ESBuild for server bundling
- Drizzle Kit for database migrations
- Replit-specific plugins for development environment

**Third-Party Services**:
- Neon Database: Serverless PostgreSQL hosting
- Google Fonts: Cairo, Tajawal, Orbitron, Exo 2 typography

**Build Process**:
- Client: Vite builds React app to `dist/public`
- Server: ESBuild bundles Express app to `dist/index.cjs`
- Dependencies are selectively bundled (allowlist in `script/build.ts`) to reduce cold start times